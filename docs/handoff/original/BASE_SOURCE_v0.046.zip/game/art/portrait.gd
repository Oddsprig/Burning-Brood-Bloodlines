class_name Portrait
extends Control
## Head-and-shoulders portrait of a unit for menus, drawn with the same layers as Paperdoll
## (FigurePainter at ~3x detail: skin, eyes, hair/beard, helm, outer armor, sleeves).
##   var p := Portrait.new(); p.custom_minimum_size = Vector2(96, 96); p.set_unit(unit)
## The picture scales to the control (integer steps when it fits), on a faction-tinted backdrop.

var unit: Unit
var show_frame := true
var _spec: Dictionary = {}
var _tex: Texture2D

func set_unit(u: Unit) -> void:
	unit = u
	_spec = FigurePainter.spec_for_unit(u) if u != null else {}
	_rebuild()

func set_spec(s: Dictionary) -> void:
	unit = null
	_spec = s
	_rebuild()

func refresh() -> void:
	set_unit(unit)

func build_image() -> Image:
	if _spec.is_empty():
		return null
	return FigurePainter.render_bust(_spec)

func _rebuild() -> void:
	var img := build_image()
	_tex = ImageTexture.create_from_image(img) if img != null else null
	queue_redraw()

func _draw() -> void:
	var r := Rect2(Vector2.ZERO, size)
	var prim: Color = _spec.get("prim", Color(0.25, 0.25, 0.3))
	var bg := prim.darkened(0.55).lerp(Color("#1a1620"), 0.4)
	draw_rect(r, bg)
	# subtle vertical gradient bands
	var bands := 6
	for i in bands:
		var y := size.y * i / bands
		draw_rect(Rect2(0, y, size.x, size.y / bands + 1), bg.lightened(0.04 * (bands - i) / bands))
	if _tex != null:
		var side := minf(size.x, size.y)
		var s := side / FigurePainter.BUST
		if s >= 1.0:
			s = floorf(s) if side - floorf(s) * FigurePainter.BUST < FigurePainter.BUST * 0.35 else s
		var dim := Vector2.ONE * FigurePainter.BUST * s
		var off := Vector2((size.x - dim.x) * 0.5, size.y - dim.y)
		draw_texture_rect(_tex, Rect2(off, dim), false)
	if show_frame:
		var sec: Color = _spec.get("sec", Color(0.8, 0.7, 0.5))
		draw_rect(r, Color("#140a10"), false, 2.0)
		draw_rect(r.grow(-2.0), sec.darkened(0.2), false, 1.0)
