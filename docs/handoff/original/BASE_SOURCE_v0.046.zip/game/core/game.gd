extends Node
## Autoload "Game": the campaign state and screen switching.
## Ownership: core fields live here. Workstreams extend behaviour from their own files
## (campaign/world.gd, ui/outfit.gd, sim/healing.gd ...) instead of growing this file.

signal changed
signal screen_changed(screen: String)

## Tests redirect saves/settings (tests/runner.gd) so they never touch the player's real save.
var SAVE_PATH := "user://save.json"
const SCREENS := {
	"title": "res://ui/title.tscn",
	"map": "res://campaign/world_map.tscn",
	"town": "res://ui/town.tscn",
	"company": "res://ui/company.tscn",
	"battle": "res://battle/battle.tscn",
	"aftermath": "res://battle/aftermath.tscn",
	"settings": "res://ui/settings.tscn",
	"gameover": "res://ui/gameover.tscn",
	"presim": "res://ui/presim.tscn",   # a new campaign: the years before (campaign/world.gd presim_step)
	"newgame": "res://ui/newgame.tscn",   # New Campaign options: world size and the years before (then presim)
}
const LOOT_FRACTION := 0.25   # loot gold = fraction of defeated enemy gear value (handoff decision)

var seed_value: int = 0
var rng := RandomNumberGenerator.new()
var day: float = 0.0
var gold: int = 0
var company: Array = []          # Array[Unit], includes captain, officers, troops, and the dead are removed
var stash: Array = []            # Array[Item], company storage
## squads[officer_uid] = {"uniform": {slot: template_id}, "material": "any"|"copper"|"tin"}
var squads: Dictionary = {}
var rep: Dictionary = {}         # faction_id -> int (-100..100)
var world: Dictionary = {}       # owned by campaign/world.gd (towns, warbands, party position, contracts)
var location: String = ""        # town id when inside a town
var contract: Dictionary = {}    # active contract (see campaign/contracts.gd)
var pending_battle: Dictionary = {}  # {"enemy": Array[Unit], "allies": Array[Unit], "contract": {}, "map": "small"|"large", "seed": int, "terrain": String}
var last_result: Dictionary = {}     # filled by finish_battle, read by the aftermath screen
var screen_params: Dictionary = {}
## Food and drink (core/food.gd): stock lots {"meal"|"beer"|"wine": [[qty, age_days], ...]}, company-wide rations,
## and the meal clock (next tick time, last drain time, marching time since).
var provisions: Dictionary = {"meal": [], "beer": [], "wine": []}
var rations: Dictionary = {"food": "normal", "drink": "ration"}
var food_clock: Dictionary = {}
var main: Node = null            # set by main.gd; holds the active screen

func _ready() -> void:
	rng.randomize()
	load_settings()

# ---------------------------------------------------------------- screens
func goto(screen: String, params: Dictionary = {}) -> void:
	screen_params = params
	if main != null:
		main.show_screen(SCREENS.get(screen, screen))
	screen_changed.emit(screen)

# ---------------------------------------------------------------- company helpers
## The player IS the mercenary captain and never takes the field (Douglas). The company is officers and
## their troops; lead_officer() is the first living officer (map icon, default selection).
func lead_officer() -> Unit:
	for u in company:
		if u.is_officer() and not u.dead:
			return u
	return null

## Game over when no one is left in the company.
func is_game_over() -> bool:
	return company.filter(func(u): return not u.dead).is_empty()

func officers() -> Array:
	return company.filter(func(u): return u.is_officer())

func squad_of(officer_uid: int) -> Array:
	return company.filter(func(u): return u.squad == officer_uid and not u.is_officer())

func unit_by_uid(uid: int) -> Unit:
	for u in company:
		if u.uid == uid:
			return u
	return null

## Units that will take the field: living, not benched, and able to fight. A unit that "cannot fight"
## (unconscious, can't stand, can't hold a weapon, blind, collapsed from blood loss, critical wound)
## stays in camp. Units that "should rest" may still fight hurt.
## Cached: fitness needs a full health report per unit, far too slow to run every map frame. The cache
## refreshes when healing runs (hourly), after battles, on load, and when the company changes size.
var _deploy_rev := 0
var _deploy_key := []
var _deploy_cache: Array = []

func invalidate_deploy() -> void:
	_deploy_rev += 1

func deployed_units() -> Array:
	var key := [_deploy_rev, company.size()]
	if key != _deploy_key:
		_deploy_cache = company.filter(func(u): return deploy_block_reason(u) == "")
		_deploy_key = key
	return _deploy_cache.filter(func(u): return not u.dead and not u.get_meta("benched", false))

## "" if the unit can deploy, else a short reason for the roster card. report: the unit's HealthReport.describe when
## the caller already has it (the roster card does: one report per man instead of two).
func deploy_block_reason(u: Unit, report: Dictionary = {}) -> String:
	if u.dead:
		return "dead"
	if u.get_meta("benched", false):
		return "benched"
	if report.has("fitness"):
		return "too hurt to fight" if report["fitness"] == "cannot fight" else ""
	var H = load("res://sim/healing.gd") if ResourceLoader.exists("res://sim/healing.gd") else null
	if H != null and H.fitness_text(u) == "cannot fight":
		return "too hurt to fight"
	return ""

func daily_wages() -> int:
	var w := 0
	for u in company:
		w += u.wage
	return w

## Daily wages, man by man while the gold lasts (officers first, then in roster order); gold never goes below
## zero. A man not paid that day counts an unpaid day (unpaid_days; desertion and morale come with economy
## spec 2). The coins paid go to each man's family purse (campaign/people.gd, via world.gd wages_paid).
func pay_wages(days: int) -> void:
	var order: Array = company.filter(func(u): return u.is_officer()) + company.filter(func(u): return not u.is_officer())
	var W = load("res://campaign/world.gd") if ResourceLoader.exists("res://campaign/world.gd") else null
	for d in days:
		for u in order:
			if u.dead or u.wage <= 0:
				continue
			var received := 0.0
			if gold >= u.wage:
				if W != null and W.has_method("wages_paid") and world.has("towns"):
					received = float(W.wages_paid(self, [[u, u.wage]]))
				else:
					received = float(u.wage)   # standalone play without the campaign economy hook
			if received == float(u.wage):
				gold -= u.wage
				u.unpaid_days = 0
				u.last_pay = received
			else:
				u.unpaid_days += 1
				u.last_pay = 0.0

func unpaid_count() -> int:
	return company.filter(func(u): return not u.dead and u.unpaid_days > 0).size()

# ---------------------------------------------------------------- new game
func new_game(game_seed: int = 0) -> void:
	var generation := new_game_begin(game_seed)
	while not new_game_slice(generation, 0):
		pass

## Shared initialization for synchronous callers and the visible startup screen.
## The returned state belongs to the caller and is never added to the saved world.
func new_game_begin(game_seed: int = 0) -> Dictionary:
	seed_value = game_seed if game_seed != 0 else randi()
	rng.seed = seed_value
	day = 0.0
	gold = 600 * Item.COIN   # coinage: 12,000 coins
	company.clear(); stash.clear(); squads.clear(); rep.clear(); world.clear()
	Unit._next_uid = 1   # a new world numbers its people and things from 1 (same seed = same world, same ids)
	contract = {}; location = ""; pending_battle = {}; last_result = {}
	invalidate_deploy()
	for fid in DB.factions:
		rep[fid] = -40 if DB.factions[fid].get("player_hostile", false) else 0
	_make_starting_company()
	Food.init_company(self)
	if ClassDB.class_exists("World") or ResourceLoader.exists("res://campaign/world.gd"):
		var W = load("res://campaign/world.gd")
		if W != null and W.has_method("generate_begin"):
			return W.generate_begin(self, rng)
	return {"generation_unavailable": true}

## Emits changed once, when the full world is safe for screens and saving to read.
func new_game_slice(generation: Dictionary, budget_usec: int) -> bool:
	if generation.is_empty():
		return true
	if generation.get("generation_unavailable", false):
		generation.clear()
		changed.emit()
		return true
	if CampaignWorld.generate_slice(self, generation, budget_usec):
		changed.emit()
		return true
	return false

func _make_starting_company() -> void:
	# The player is the captain (off the field); the company starts with four officers and their squads.
	var picks := [["middle_kingdom", 1], ["northern_clans", 1], ["northern_clans", 0], ["middle_kingdom", 0]]
	for p in picks:
		var off := Factory.make_troop(rng, p[0], DB.factions[p[0]]["troops"][p[1]], 2)
		off.role = "officer"; off.faction = "player"; off.wage = 12 * Item.COIN
		for s in off.skills:
			if off.skills[s] > 0:
				off.skills[s] += 1
		company.append(off)
		squads[off.uid] = {"uniform": {}, "material": "any"}
		for i in 3:
			var tr := Factory.make_troop(rng, p[0], DB.factions[p[0]]["troops"][p[1]], 1)
			tr.faction = "player"; tr.squad = off.uid; tr.wage = 4 * Item.COIN
			company.append(tr)
		# Uniform rule defaults to the officer's own troop template loadout (first choices).
		var lo: Dictionary = DB.factions[p[0]]["troops"][p[1]]["loadout"]
		for slot in lo:
			if lo[slot][0] != "":
				squads[off.uid]["uniform"][slot] = lo[slot][0]

# ---------------------------------------------------------------- battle hand-off
func start_battle(params: Dictionary) -> void:
	pending_battle = params
	if not pending_battle.has("seed"):
		pending_battle["seed"] = rng.randi()
	for u in company:   # v0.014: a legendary piece's carriers go in its history
		Legends.touch_unit(u)
	Food.sync(self)                       # digestion and buzz up to now (the morning mug lands before a battle)
	Food.spawn_battle(self, pending_battle)   # enemies: belly/buzz from their supply and race
	BowsEcon.fill_company_quivers(self)      # bows: quivers topped up from the company's arrows
	goto("battle")

## Called by the battle screen when the sim ends.
## result = {"winner": 0 (player) | 1 (enemy) | -1, "player_units": Array[Unit], "enemy_units": Array[Unit],
##           "enemy_fallen": Array[Unit] (dead or fled), "events": Array}
func finish_battle(result: Dictionary) -> void:
	var loot := 0
	var dead_names := []
	var won := int(result.get("winner", -1)) == 0
	var kept_items := []
	var kept_from_dead := 0
	if won:
		var sp := Loot.spoils(result.get("enemy_units", []).filter(func(x): return x is Unit and not company.has(x)),
			result.get("enemy_fled", []), int(pending_battle.get("seed", 0)) + 77, loot_fraction(), "your company")
		loot = int(sp["gold"]) + int(sp["coin"])
		result["loot_coin"] = int(sp["coin"])
		kept_items = sp["items"]
		stash.append_array(kept_items)
		result["scrap_kg"] = sp["scrap_kg"]   # economy hook: scrap goes into the nearest town's stock
		result["scrap_gold"] = int(sp.get("scrap_gold", 0))   # v0.014: world.gd re-prices it at the town's scrap price
		# The company holds the field: its dead men's gear comes back to the stash.
		for u in company:
			if u.dead:
				for s in u.equip.keys():
					stash.append(u.equip[s]); kept_from_dead += 1
				u.equip.clear()
		# bows: arrows recovered from the field (broken ones are scrap), the enemy's quivers, the dead men's quivers
		result["arrows_got"] = BowsEcon.after_battle(self, result, sp.get("arrows", {}))
	# v0.014 gear damage: the company's own snapped, split, cracked or shattered pieces come off the men (and out of the
	# stash, where the dead men's gear went) and the quartermaster sells them as scrap of their metal (real mass)
	var own_broken := []
	for it in stash:
		if it.broken:
			own_broken.append(it)
	for it in own_broken:
		stash.erase(it)
	var own_scrap := Loot.strip_broken(company)
	for it in own_broken:
		own_scrap[it.material] = float(own_scrap.get(it.material, 0.0)) + it.mass()
	if not own_scrap.is_empty():
		var sc: Dictionary = result.get("scrap_kg", {})
		Loot.add_kg(sc, own_scrap)
		result["scrap_kg"] = sc
		result["own_scrap_kg"] = own_scrap
		for m in own_scrap:   # paid at the scrap rate the spoils use (a fraction of the metal's worth by mass)
			var sg := int(round(float(own_scrap[m]) * float(DB.materials.get(m, {}).get("value", 1)) * 6.0 * Item.COIN * loot_fraction()))
			loot += sg
			result["scrap_gold"] = int(result.get("scrap_gold", 0)) + sg   # (world.gd re-prices it at the town's scrap price)
	gold += loot
	var H = load("res://sim/healing.gd") if ResourceLoader.exists("res://sim/healing.gd") else null
	Food.after_battle(company)   # -10 belly for the fight; battle-only food/drink multipliers off
	Food.after_battle(result.get("enemy_units", []).filter(func(x): return x is Unit and not company.has(x)))
	for u in company.duplicate():
		if H != null and not u.dead:
			H.after_battle(u)
		u.battles += 1
		if u.dead:
			dead_names.append(u.name)
			company.erase(u)
			squads.erase(u.uid)
			for t in company:
				if t.squad == u.uid:
					t.squad = -1
	result["loot_gold"] = loot
	result["loot_items"] = kept_items
	result["fallen_gear"] = kept_from_dead
	result["dead_names"] = dead_names
	last_result = result
	var W = load("res://campaign/world.gd") if ResourceLoader.exists("res://campaign/world.gd") else null
	if W != null and W.has_method("on_battle_result"):
		W.on_battle_result(self, result)
	pending_battle = {}
	invalidate_deploy()
	changed.emit()
	if is_game_over():
		goto("gameover")
	else:
		goto("aftermath")

# ---------------------------------------------------------------- time
## Advances campaign time. Healing (sim/healing.gd) and wages hook in here.
## healer_skill (optional): skill of the town healer tending the company while resting.
const HEAL_STEP := 4.0 / 24.0   # heal in 4-hour batches on the map (each batch is ~3 ms for a full company)
var _heal_acc := 0.0

func advance_time(days: float, in_town: bool = false, healer_skill: int = 0) -> void:
	var before := int(floor(day))
	day += days
	var whole := int(floor(day)) - before
	if whole > 0:
		pay_wages(whole)
	# Healing runs in 4-hour batches, not every map frame (it was most of the per-frame cost).
	_heal_acc += days
	if _heal_acc >= HEAL_STEP or in_town:
		var H = load("res://sim/healing.gd") if ResourceLoader.exists("res://sim/healing.gd") else null
		if H != null and H.has_method("heal"):
			for u in company:
				H.heal(u, _heal_acc, in_town, healer_skill)
		_heal_acc = 0.0
	if whole > 0 or in_town:
		invalidate_deploy()   # fitness changes slowly; recheck once a day (it costs a health report per unit)
	# food and drink: meals/drinks at the morning, midday and evening ticks (a float compare per frame otherwise)
	Food.on_time(self, days, in_town)
	# strategy layer: party travel, warbands, daily spawns, town refresh, contract deadlines
	var Wt = load("res://campaign/world.gd") if ResourceLoader.exists("res://campaign/world.gd") else null
	if Wt != null and Wt.has_method("on_time"):
		Wt.on_time(self, days, in_town)
	changed.emit()

# ---------------------------------------------------------------- save / load
func save_game() -> void:
	wait_save()
	_write_save(SAVE_PATH, _save_tree())

## Autosave without the freeze (v0.014, Douglas "long loading screen ... map screen to town screen"): a Large
## world's save was ~2.3 s, half of it JSON.stringify. The save tree is built here on the main thread (a fresh copy
## that shares no container with the live game), then turned into JSON and written by a worker thread. Same file
## as save_game. load_game, save_game and quitting wait for it; a second autosave queues behind it (its worker waits
## for the first write, so the newer save always lands last).
var _save_task := -1

func save_game_async() -> void:
	var d := _save_tree()
	_save_task = WorkerThreadPool.add_task(_write_after.bind(_save_task, SAVE_PATH, d), false, "autosave")

static func _write_after(prev: int, path: String, d: Dictionary) -> void:
	if prev != -1:
		WorkerThreadPool.wait_for_task_completion(prev)
	_write_save(path, d)

func wait_save() -> void:
	if _save_task != -1:
		WorkerThreadPool.wait_for_task_completion(_save_task)
		_save_task = -1

func _notification(what: int) -> void:
	if what in [NOTIFICATION_WM_CLOSE_REQUEST, NOTIFICATION_PREDELETE, NOTIFICATION_APPLICATION_PAUSED]:
		wait_save()   # never quit (or go to the phone's background) half way through writing the save
	if what == NOTIFICATION_PREDELETE and ResourceLoader.has_cached("res://campaign/map_terrain.gd"):
		load("res://campaign/map_terrain.gd").free_cache()   # the map layer's kept decor canvas items

## Written to a side file first, then moved over the save: a crash mid-write leaves the old save whole.
static func _write_save(path: String, d: Dictionary) -> void:
	var tmp := path + ".tmp"
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		return
	f.store_string(JSON.stringify(d))
	f.close()
	DirAccess.rename_absolute(ProjectSettings.globalize_path(tmp), ProjectSettings.globalize_path(path))

## The save as plain data. Everything outside world and contract is deep-copied (small); _serialize copies every
## container it walks and to_dict output is deep-copied, so nothing in it is shared with the live game.
func _save_tree() -> Dictionary:
	var d := {"version": 1, "seed": seed_value, "day": day, "gold": gold, "next_unit_uid": Unit._next_uid,
		"company": company.map(func(u): return u.to_dict()),
		"stash": stash.map(func(i): return i.to_dict()),
		"squads": _keys_to_str(squads), "rep": rep, "location": location,
		"provisions": Food.stock_to_save(self), "rations": rations, "food_clock": food_clock}.duplicate(true)
	d["world"] = _serialize(world)
	d["contract"] = _serialize(contract)
	return d

func has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH)

func load_game() -> bool:
	wait_save()
	if not has_save():
		return false
	var d = JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
	if d == null:
		return false
	Unit._next_uid = maxi(1, int(d.get("next_unit_uid", 1)))
	seed_value = int(d.get("seed", 0)); rng.seed = seed_value
	day = d.get("day", 0.0); gold = int(d.get("gold", 0))
	company = d.get("company", []).map(func(x): return Unit.from_dict(x))
	if gold < 0:
		# older saves let wages run the purse negative: clamp, and the owed days become unpaid days
		var dw := maxi(1, daily_wages())
		var owed_days := int(ceil(float(-gold) / float(dw)))
		for u in company:
			u.unpaid_days += owed_days
		gold = 0
	for u in company:
		if u.role == "captain":
			u.role = "officer"   # pre-v0.003 saves had a captain unit; the player is the captain now
	invalidate_deploy()
	stash = d.get("stash", []).map(func(x): return Item.from_dict(x))
	squads = {}
	for k in d.get("squads", {}):
		squads[int(k)] = d["squads"][k]
	rep = d.get("rep", {}); world = _deserialize(d.get("world", {})); location = d.get("location", "")
	contract = _deserialize(d.get("contract", {}))
	Unit._next_uid = maxi(Unit._next_uid, ServiceIdentity.uid_floor(self))
	if d.has("provisions"):
		provisions = Food.stock_from_save(d["provisions"])
		var r: Dictionary = d.get("rations", {})
		rations = {"food": str(r.get("food", "normal")), "drink": str(r.get("drink", "ration"))}
		food_clock = {}
		var fc: Dictionary = d.get("food_clock", {})
		for k in fc:
			food_clock[k] = int(fc[k]) if k == "rot" else float(fc[k])
		if food_clock.is_empty():
			food_clock = {"next": Food.next_tick_after(day), "last": day, "march": 0.0}
	else:
		Food.init_company(self)   # saves from before food and drink: starting stock, default rations
	var Wl = load("res://campaign/world.gd") if ResourceLoader.exists("res://campaign/world.gd") else null
	if Wl != null and Wl.has_method("after_load"):
		Wl.after_load(self)   # JSON floats -> ints for world fields
	changed.emit()
	return true

func _keys_to_str(dict: Dictionary) -> Dictionary:
	var o := {}
	for k in dict:
		o[str(k)] = dict[k]
	return o

## Units and Items inside world/contract dictionaries are stored with a type tag.
## Speed (v0.014, Douglas "long loading screen ... map screen to town screen"): a Large world's save walks ~25 MB
## of plain data, so each container is copied natively (shallow duplicate) and the walk only replaces what is not
## a plain value (nil, bool, int, float, string: typeof <= TYPE_STRING); no call or lambda per plain element.
## Typed containers take the old element-by-element copy (a tag dictionary cannot go into them). Same output.
func _serialize(v):
	match typeof(v):
		TYPE_DICTIONARY:
			if v.is_typed():
				var o0 := {}
				for k in v:
					o0[k] = _serialize(v[k])
				return o0
			var o: Dictionary = v.duplicate()
			for k in o:
				var x = o[k]
				if typeof(x) > TYPE_STRING:
					o[k] = _serialize(x)
			return o
		TYPE_ARRAY:
			if v.is_typed():
				var a0 := []
				if v.get_typed_builtin() <= TYPE_STRING:
					a0.assign(v)   # untyped, as before: plain values only
					return a0
				for x in v:
					a0.append(_serialize(x))
				return a0
			var a: Array = v.duplicate()
			var i := 0
			for x in a:
				if typeof(x) > TYPE_STRING:
					a[i] = _serialize(x)
				i += 1
			return a
		TYPE_OBJECT:
			if v is Unit:
				return {"__unit": v.to_dict().duplicate(true)}
			if v is Item:
				return {"__item": v.to_dict().duplicate(true)}
		TYPE_VECTOR2:
			return {"__v2": [v.x, v.y]}
	return v

## Rebuilds in place: the tree is the freshly parsed JSON, owned by load_game alone (no copy needed).
func _deserialize(v):
	match typeof(v):
		TYPE_DICTIONARY:
			if v.has("__unit"):
				return Unit.from_dict(v["__unit"])
			if v.has("__item"):
				return Item.from_dict(v["__item"])
			if v.has("__v2"):
				return Vector2(v["__v2"][0], v["__v2"][1])
			for k in v:
				var x = v[k]
				if typeof(x) > TYPE_STRING:
					v[k] = _deserialize(x)
			return v
		TYPE_ARRAY:
			var i := 0
			for x in v:
				if typeof(x) > TYPE_STRING:
					v[i] = _deserialize(x)
				i += 1
			return v
	return v

# ---------------------------------------------------------------- company-level skills
## Map and economy skills (appraiser, negotiator, tracker, organizer, judge) use the company's best member.
func best_skill(skill: String) -> int:
	var best := 0
	for u in company:
		if not u.dead:
			best = maxi(best, u.skill(skill))
	return best

## Loot fraction of defeated enemy gear value: base 25%, best Appraiser adds up to +10% (tuned).
func loot_fraction() -> float:
	return LOOT_FRACTION + 0.005 * best_skill("appraiser")

# ---------------------------------------------------------------- settings (persist outside the save)
var SETTINGS_PATH := "user://settings.json"
## Event animations are kept in code but OFF by default (Douglas: compare with and without later).
const DEFAULT_SETTINGS := {
	"anim_limb_flyoff": false, "anim_spurts": false, "anim_lodged": false, "anim_wrestle": false,
	"battle_speed": 1.0,
	"gore": "full",   # v0.014 (Douglas 22:51): "full" | "reduced" (a later phone-store build): blood, decals and log words
}
## Settings with named choices (the screen cycles through them): key -> {label, options [value, shown name]}.
const SETTING_CHOICES := {
	"gore": {"label": "Gore", "options": [["full", "Full"], ["reduced", "Reduced"]],
		"hint": "Full: blood sprays, pools, trails and wounds on the fighters, severed parts stay on the field, vivid log. Reduced: less blood, no severed-part decals, milder log words."},
}

func gore_full() -> bool:
	return String(setting("gore")) != "reduced"
const SETTING_LABELS := {
	"anim_limb_flyoff": "Severed parts fly off",   # (v0.014: arterial spurts are part of Gore: Full, no toggle)
	"anim_lodged": "Stuck weapons shown", "anim_wrestle": "Wrestling animations",
}
var settings: Dictionary = DEFAULT_SETTINGS.duplicate()

func setting(key: String):
	return settings.get(key, DEFAULT_SETTINGS.get(key))

func set_setting(key: String, value) -> void:
	settings[key] = value
	CombatText.gore_full = gore_full()   # v0.014: the log's word set follows the Gore setting
	var f := FileAccess.open(SETTINGS_PATH, FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(settings))

func load_settings() -> void:
	settings = DEFAULT_SETTINGS.duplicate()
	if FileAccess.file_exists(SETTINGS_PATH):
		var d = JSON.parse_string(FileAccess.get_file_as_string(SETTINGS_PATH))
		if d is Dictionary:
			settings.merge(d, true)
	CombatText.gore_full = gore_full()
