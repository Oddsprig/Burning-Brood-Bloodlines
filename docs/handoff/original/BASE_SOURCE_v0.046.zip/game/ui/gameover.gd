extends Control
## Game over: the company is gone. The player (the captain) never fights, so this is the only loss.

func _ready() -> void:
	var f := UiKit.screen_frame(self, "The Company Is No More")
	var root: VBoxContainer = f["root"]
	var r: Dictionary = Game.last_result
	var lines := ["Day %d. The last of your company has fallen." % int(Game.day)]
	var names: Array = r.get("dead_names", [])
	if not names.is_empty():
		lines.append("Fallen in the last battle: " + ", ".join(names) + ".")
	lines.append("Coins left in the chest: %d." % Game.gold)
	for l in lines:
		root.add_child(UiKit.label(l, "", true))
	root.add_child(UiKit.spacer())
	var row := UiKit.hbox(12)
	root.add_child(row)
	row.add_child(UiKit.button("New Campaign", func():
		Game.goto("newgame", {"back": "title"}), "", 260))   # options, then the years before; presim saves when the map opens
	row.add_child(UiKit.button("Title", func(): Game.goto("title"), "", 200))
	# The old save would load a dead company; replace it so Continue isn't a trap.
	Game.wait_save()   # an autosave still writing would bring the save back
	if FileAccess.file_exists(Game.SAVE_PATH):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(Game.SAVE_PATH))
