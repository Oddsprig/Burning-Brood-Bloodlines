extends Node2D
## Campaign map screen ("map"). Tap/click to travel, tap a town to go there (enter when adjacent),
## tap a warband to scout it. Time passes while the party travels (or while waiting).
## Camera: WASD/arrows (cam_*), drag to pan, wheel / pinch to zoom.

const SEC_PER_DAY := 5.0
const ZOOM_MIN := 0.45
const ZOOM_MAX := 2.6
const DRAG_THRESHOLD := 12.0
const TOWN_ENTER_DIST := 56.0

var terrain: Node2D
var tracks_layer: Node2D   # tracks: noticed tracks + last-seen circle (campaign/map_tracks.gd), static, redraws on change
var overlay: Node2D
var sites: Node2D
var bands_root: Node2D
var party_icon: MapToken   # map tokens
var cam: Camera2D
var icons := {}          # wid -> MapToken (map tokens)
var follow := true
var speed_mult := 1
var pursue_wid := ""
var selected := {}       # {"kind": "warband"|"town", "id": ...}

# input state
var _press_pos := Vector2.ZERO
var _pressing := false
var _dragging := false

# HUD
var hud: CanvasLayer
var lbl_day: Label
var daylight: CanvasModulate   # one cheap full-map tint for night/dawn/dusk and season
var lbl_gold: Label
var lbl_wages: Label
var lbl_contract: Label
var lbl_log: Label
var lbl_news: Label   # diplomacy ticker
var lbl_toast: Label
var btn_wait: Button
var btn_speed: Button
var info_panel: PanelContainer
var info_title: Label
var info_body: Label
var info_buttons: HBoxContainer
var enc_fight: Button
var enc_panel: PanelContainer
var enc_body: Label
var enc_title: Label
var modal_host: Control   # economy spec 2: themed layer for the rank-tree panel (ui/army_panel.gd)
var _toast_t := 0.0
var _hud_t := 0.0

func _ready() -> void:
	if Game.world.is_empty() or not Game.world.has("towns"):
		Game.new_game()
	daylight = CanvasModulate.new()   # tints the map only; the HUD lives on a CanvasLayer
	add_child(daylight)
	daylight.color = Calendar.tint(Game.day)
	var w: Dictionary = Game.world
	# back from a town: the party stands at the gate
	if Game.location != "":
		var t: Dictionary = w["towns"].get(Game.location, {})
		Game.location = ""
		if not t.is_empty():
			w["party"]["pos"] = CampaignWorld.nearest_passable(w, t["pos"] + Vector2(0, 30))
	w["party"]["arrived"] = ""
	terrain = Node2D.new()
	terrain.set_script(load("res://campaign/map_terrain.gd"))
	add_child(terrain)
	terrain.setup(w)
	tracks_layer = load("res://campaign/map_tracks.gd").new()   # tracks
	add_child(tracks_layer)
	overlay = Node2D.new()
	overlay.draw.connect(_draw_overlay)
	add_child(overlay)
	sites = load("res://campaign/map_sites.gd").new()   # monsters wave 1: known lairs and bandit camps
	add_child(sites)
	sites.sync(Game)
	bands_root = Node2D.new()
	bands_root.y_sort_enabled = true
	add_child(bands_root)
	# map tokens: the company is one banner token, always drawn on top (art/map_tokens.gd)
	party_icon = MapToken.new()
	party_icon.set_texture("player", MapTokens.texture("player"))
	party_icon.z_index = 1
	bands_root.add_child(party_icon)
	cam = Camera2D.new()
	cam.limit_left = -200; cam.limit_top = -200
	cam.limit_right = WorldGen.W * WorldGen.CELL + 200
	cam.limit_bottom = WorldGen.H * WorldGen.CELL + 200
	add_child(cam)
	cam.make_current()
	cam.position = w["party"]["pos"]
	_build_hud()
	tracks_layer.setup(self)   # tracks: tapping the contract line centres the map on the target / last-seen spot
	_sync_icons()
	_refresh_hud()

# ================================================================== loop
func _process(delta: float) -> void:
	var w: Dictionary = Game.world
	var party: Dictionary = w["party"]
	# camera keys
	var pan := Input.get_vector("cam_left", "cam_right", "cam_up", "cam_down")
	if pan != Vector2.ZERO:
		cam.position += pan * 900.0 * delta / cam.zoom.x
		follow = false
	# time
	var enc: String = w.get("encounter", "")
	if enc != "" and not w["warbands"].has(enc):
		w["encounter"] = ""; enc = ""
	if enc == "":
		if pursue_wid != "":
			_update_pursuit()
		var moving := CampaignWorld.is_travelling(Game)
		if moving or party.get("waiting", false):
			Game.advance_time(delta / SEC_PER_DAY * speed_mult, false)
		var arrived: String = party.get("arrived", "")
		if arrived != "":
			party["arrived"] = ""
			_try_enter(arrived)
			return
	_show_encounter(w.get("encounter", ""))
	if follow:
		cam.position = cam.position.lerp(party["pos"], minf(1.0, delta * 6.0))
	cam.position = cam.position.clamp(Vector2.ZERO, Vector2(WorldGen.W, WorldGen.H) * WorldGen.CELL)
	party_icon.position = party["pos"]
	_sync_icons()
	overlay.queue_redraw()
	_hud_t -= delta
	if _hud_t <= 0.0:
		_hud_t = 0.2
		_refresh_hud()
	if _toast_t > 0.0:
		_toast_t -= delta
		lbl_toast.visible = _toast_t > 0.0

## map tokens: one cached-texture MapToken per visible force (type / faction / pips / stance re-checked a few
## times a second), drawn in map-y order with the company on top, sized by zoom, night darkening capped at 30%.
func _sync_icons() -> void:
	var vis := CampaignWorld.visible_warbands(Game)
	MapTokens.sync(bands_root, icons, Game, vis, cam.zoom.x, Engine.get_process_frames() % 12 == 0, party_icon)
	bands_root.modulate = MapTokens.night_comp(daylight.color)

func _update_pursuit() -> void:
	var w: Dictionary = Game.world
	var wb: Dictionary = w["warbands"].get(pursue_wid, {})
	if wb.is_empty() or not CampaignWorld.visible_warbands(Game).has(pursue_wid):
		pursue_wid = ""
		return
	var party: Dictionary = w["party"]
	if (wb["pos"] as Vector2).distance_to(party["pos"]) < 40.0:
		pursue_wid = ""
		CampaignWorld.stop_travel(Game)
		_select({"kind": "warband", "id": wb["id"]})
		return
	if (party["target"] as Vector2).distance_to(wb["pos"]) > 24.0 or not CampaignWorld.is_travelling(Game):
		CampaignWorld.set_travel(Game, wb["pos"])

# ================================================================== drawing overlay
func _draw_overlay() -> void:
	var w: Dictionary = Game.world
	var party: Dictionary = w["party"]
	var path: Array = party["path"]
	if not path.is_empty():
		var prev: Vector2 = party["pos"]
		var acc := 0.0
		for q in path:
			var seg: Vector2 = q - prev
			var L := seg.length()
			while acc < L:
				overlay.draw_circle(prev + seg * (acc / L), 2.6, Color(1, 0.95, 0.75, 0.9))
				acc += 14.0
			acc -= L
			prev = q
		var dst: Vector2 = path[-1]
		overlay.draw_arc(dst, 9.0, 0, TAU, 20, Color("#ffe08a"), 2.5)
		overlay.draw_line(dst + Vector2(-5, -5), dst + Vector2(5, 5), Color("#ffe08a"), 2.5)
		overlay.draw_line(dst + Vector2(-5, 5), dst + Vector2(5, -5), Color("#ffe08a"), 2.5)
	var pulse := 0.5 + 0.5 * sin(Time.get_ticks_msec() / 250.0)
	var tgt: String = Game.contract.get("target_id", "")
	if Game.contract.get("kind", "") == "escort" and w["warbands"].has(tgt):
		# escort radius: stay inside it or the merchants halt (and eventually give up)
		var cp: Vector2 = w["warbands"][tgt]["pos"]
		var inside: bool = (w["party"]["pos"] as Vector2).distance_to(cp) <= Caravans.ESCORT_RADIUS
		var rc := Color(0.55, 1.0, 0.6, 0.55) if inside else Color(1.0, 0.4, 0.3, 0.75)
		overlay.draw_arc(cp, Caravans.ESCORT_RADIUS, 0, TAU, 64, rc, 2.5)
	if tgt != "" and icons.has(tgt):   # tracks: a hunted target out of sight is not marked (its last-seen circle is)
		var tp: Vector2 = w["warbands"][tgt]["pos"]
		overlay.draw_arc(MapTokens.center(tp, cam.zoom.x), (MapTokens.HIT_R + 2.0 + pulse * 4.0) / cam.zoom.x, 0, TAU, 32, Color(1, 0.8, 0.2, 0.9), 3.0)   # map tokens
	var ctown: String = Game.contract.get("town_id", "")
	if Game.contract.get("kind", "") == "defend" and w["towns"].has(ctown):
		overlay.draw_arc(w["towns"][ctown]["pos"], 46.0 + pulse * 4.0, 0, TAU, 40, Color(1, 0.8, 0.2, 0.8), 3.0)
	if selected.get("kind", "") == "warband" and w["warbands"].has(selected["id"]):
		overlay.draw_arc(MapTokens.center(w["warbands"][selected["id"]]["pos"], cam.zoom.x), MapTokens.HIT_R / cam.zoom.x, 0, TAU, 28, Color.WHITE, 2.0)   # map tokens
	elif selected.get("kind", "") == "town" and w["towns"].has(selected["id"]):
		overlay.draw_arc(w["towns"][selected["id"]]["pos"], 40.0, 0, TAU, 36, Color.WHITE, 2.0)

# ================================================================== input
func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed:
				_pressing = true; _dragging = false; _press_pos = mb.position
			elif _pressing:
				_pressing = false
				if not _dragging:
					_tap(get_global_mouse_position())
		elif mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_UP:
			_zoom_at(1.12, mb.position)
		elif mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_zoom_at(1.0 / 1.12, mb.position)
	elif event is InputEventMouseMotion and _pressing:
		var mm := event as InputEventMouseMotion
		if not _dragging and mm.position.distance_to(_press_pos) > DRAG_THRESHOLD:
			_dragging = true
		if _dragging:
			cam.position -= mm.relative / cam.zoom.x
			follow = false
	elif event is InputEventMagnifyGesture:
		_zoom_at((event as InputEventMagnifyGesture).factor, (event as InputEventMagnifyGesture).position)
	elif event is InputEventPanGesture:
		cam.position += (event as InputEventPanGesture).delta * 8.0 / cam.zoom.x
		follow = false

func _zoom_at(f: float, screen_pos: Vector2) -> void:
	var before := get_global_mouse_position()
	var z := clampf(cam.zoom.x * f, ZOOM_MIN / WorldGen.K, ZOOM_MAX)   # war pick 5: zoom out as far over the 1.5x map
	cam.zoom = Vector2(z, z)
	terrain.set_zoom(z)   # world size: the decor hides when zoomed far out over a large map (the land still shows)
	# keep the point under the cursor fixed
	var vp := get_viewport_rect().size
	var after := cam.get_screen_center_position() + (screen_pos - vp * 0.5) / z
	cam.position += before - after

func _tap(p: Vector2) -> void:
	var w: Dictionary = Game.world
	if w.get("encounter", "") != "":
		return
	var z := cam.zoom.x
	# warbands first (map tokens: hit circle r=30 screen px around each token)
	var best := MapTokens.pick(icons, w["warbands"], p, z)
	if best != "":
		_select({"kind": "warband", "id": best})
		return
	var tbest := ""; var tbd := maxf(34.0, 40.0 / z)
	for tid in w["towns"]:
		var d: float = (w["towns"][tid]["pos"] as Vector2).distance_to(p)
		if d < tbd:
			tbd = d; tbest = tid
	if tbest != "":
		var t: Dictionary = w["towns"][tbest]
		pursue_wid = ""
		if (w["party"]["pos"] as Vector2).distance_to(t["pos"]) < TOWN_ENTER_DIST:
			_try_enter(tbest)
		elif CampaignWorld.set_travel(Game, t["pos"], tbest):
			follow = true
			_select({"kind": "town", "id": tbest})
		else:
			toast("No road leads there.")
		return
	if tracks_layer.tap(p, maxf(12.0, 16.0 / z)):   # tracks: read a noticed track (age, numbers, kind, heading)
		pursue_wid = ""
		_select({"kind": "track", "id": str(tracks_layer.track_sel[1])})
		return
	_close_info()
	pursue_wid = ""
	if CampaignWorld.set_travel(Game, p):
		follow = true
	else:
		toast("The company can't get there.")

func _try_enter(tid: String) -> void:
	var t: Dictionary = Game.world["towns"].get(tid, {})
	if t.is_empty():
		return
	if CampaignWorld.is_hostile(Game, t["faction"]):
		toast("The gates of %s are barred to you." % t["name"])
		return
	CampaignWorld.stop_travel(Game)
	Game.world["party"]["waiting"] = false
	Game.location = tid
	Game.goto("town", {"arrive": true})   # the town autosaves on arrival (not on coming back from its sub-screens)

# ================================================================== HUD
func _style(bg: Color, border: Color = Color("#d8b25a")) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(2)
	s.set_corner_radius_all(8)
	s.content_margin_left = 12; s.content_margin_right = 12
	s.content_margin_top = 8; s.content_margin_bottom = 8
	return s

func _button(text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(96, 56)
	b.add_theme_font_size_override("font_size", 20)
	b.add_theme_stylebox_override("normal", _style(Color("#3a2c1c"), Color("#c89a48")))
	b.add_theme_stylebox_override("hover", _style(Color("#4c3a24"), Color("#f0c060")))
	b.add_theme_stylebox_override("pressed", _style(Color("#5e4626"), Color("#ffe08a")))
	b.add_theme_stylebox_override("disabled", _style(Color("#2a2420"), Color("#5a4a3a")))
	b.focus_mode = Control.FOCUS_NONE
	b.pressed.connect(cb)
	return b

func _label(fs: int = 20, col: Color = Color("#fff3d6")) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", fs)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	l.add_theme_constant_override("outline_size", 4)
	return l

func _build_hud() -> void:
	hud = CanvasLayer.new()
	add_child(hud)
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(root)
	# top bar
	var top := PanelContainer.new()
	top.add_theme_stylebox_override("panel", _style(Color(0.1, 0.07, 0.04, 0.85)))
	top.set_anchors_preset(Control.PRESET_TOP_WIDE)
	top.offset_left = 8; top.offset_right = -8; top.offset_top = 8
	root.add_child(top)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 18)
	top.add_child(hb)
	# layout: the stats column takes whatever the buttons leave; its rows wrap or trim, never push the bar wider
	var stats := VBoxContainer.new()
	stats.add_theme_constant_override("separation", 0)
	stats.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	stats.custom_minimum_size.x = 160
	hb.add_child(stats)
	var row1 := HFlowContainer.new()   # layout: wraps day / gold / wages onto a second line when narrow
	row1.add_theme_constant_override("h_separation", 22)
	row1.add_theme_constant_override("v_separation", 0)
	stats.add_child(row1)
	lbl_day = _label(22); row1.add_child(lbl_day)
	lbl_gold = _label(22, Color("#ffd75a")); row1.add_child(lbl_gold)
	lbl_wages = _label(18, Color("#e8c8a0")); row1.add_child(lbl_wages)
	lbl_contract = _label(17, Color("#bfe6ff"))
	lbl_contract.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS   # layout
	lbl_contract.custom_minimum_size = Vector2(0, 0)
	lbl_contract.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	stats.add_child(lbl_contract)
	btn_wait = _button("Wait", _on_wait); hb.add_child(btn_wait)
	btn_speed = _button("x1", _on_speed); btn_speed.custom_minimum_size = Vector2(64, 56); hb.add_child(btn_speed)
	hb.add_child(_button("Find", _on_center))
	hb.add_child(_button("Company", func(): Game.goto("company", {"back": "map"})))
	hb.add_child(_button("Save", _on_save))
	hb.add_child(_button("Settings", func(): Game.goto("settings", {"back": "map"})))
	# diplomacy: news ticker for declarations (war, peace, pacts), under the top bar, no animation
	lbl_news = _label(19, Color("#ffcf7a"))
	# layout: full width with margins, wraps instead of running off the right edge
	lbl_news.set_anchors_preset(Control.PRESET_TOP_WIDE)
	lbl_news.offset_top = 92; lbl_news.offset_left = 24; lbl_news.offset_right = -24
	lbl_news.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	lbl_news.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lbl_news.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(lbl_news)
	# event log, bottom-left
	lbl_log = _label(15, Color("#f4ead2"))
	lbl_log.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	lbl_log.offset_left = 14; lbl_log.offset_bottom = -12; lbl_log.offset_top = -100; lbl_log.offset_right = 700
	lbl_log.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
	lbl_log.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS   # layout: long log lines trim, never widen
	lbl_log.clip_text = true
	lbl_log.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(lbl_log)
	# toast
	lbl_toast = _label(24, Color("#fff0b0"))
	# layout: full width with margins, wraps
	lbl_toast.set_anchors_preset(Control.PRESET_TOP_WIDE)
	lbl_toast.offset_top = 120; lbl_toast.offset_left = 40; lbl_toast.offset_right = -40
	lbl_toast.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	lbl_toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lbl_toast.visible = false
	root.add_child(lbl_toast)
	# info panel (bottom-right): scouting / town
	info_panel = PanelContainer.new()
	info_panel.add_theme_stylebox_override("panel", _style(Color(0.1, 0.07, 0.04, 0.92)))
	info_panel.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	info_panel.offset_left = -440; info_panel.offset_top = -300; info_panel.offset_right = -10; info_panel.offset_bottom = -10
	info_panel.visible = false
	info_panel.grow_horizontal = Control.GROW_DIRECTION_BEGIN   # layout: a tall report grows up, not off the bottom
	info_panel.grow_vertical = Control.GROW_DIRECTION_BEGIN
	root.add_child(info_panel)
	var iv := VBoxContainer.new()
	info_panel.add_child(iv)
	info_title = _label(22, Color("#ffd98a")); iv.add_child(info_title)
	info_body = _label(17); info_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info_body.custom_minimum_size = Vector2(400, 0)
	iv.add_child(info_body)
	info_buttons = HBoxContainer.new(); info_buttons.add_theme_constant_override("separation", 10)
	iv.add_child(info_buttons)
	# encounter panel (centre)
	enc_panel = PanelContainer.new()
	enc_panel.add_theme_stylebox_override("panel", _style(Color(0.12, 0.05, 0.03, 0.95), Color("#e06a3a")))
	enc_panel.set_anchors_preset(Control.PRESET_CENTER)
	enc_panel.offset_left = -300; enc_panel.offset_right = 300; enc_panel.offset_top = -150; enc_panel.offset_bottom = 150
	enc_panel.visible = false
	root.add_child(enc_panel)
	var ev := VBoxContainer.new(); ev.add_theme_constant_override("separation", 10)
	enc_panel.add_child(ev)
	enc_title = _label(28, Color("#ffb070")); ev.add_child(enc_title)
	enc_body = _label(19); enc_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	enc_body.custom_minimum_size = Vector2(560, 0)
	ev.add_child(enc_body)
	var eb := HBoxContainer.new(); eb.add_theme_constant_override("separation", 20)
	eb.alignment = BoxContainer.ALIGNMENT_CENTER
	ev.add_child(eb)
	var fight := _button("Fight", _on_fight); fight.custom_minimum_size = Vector2(180, 64)
	enc_fight = fight
	var flee := _button("Retreat", _on_retreat); flee.custom_minimum_size = Vector2(180, 64)
	eb.add_child(fight); eb.add_child(flee)
	modal_host = Control.new()
	modal_host.set_anchors_preset(Control.PRESET_FULL_RECT)
	modal_host.mouse_filter = Control.MOUSE_FILTER_IGNORE
	modal_host.theme = UiTheme.get_theme()
	root.add_child(modal_host)

func _refresh_hud() -> void:
	var d: float = Game.day
	lbl_day.text = Calendar.text(d)
	if daylight != null:
		daylight.color = Calendar.tint(d)
	lbl_gold.text = "%s coins" % UiKit.thousands(int(Game.gold))
	lbl_wages.text = "wages %d/day  |  %d men%s" % [Game.daily_wages(), Game.deployed_units().size(),
		("  |  %d unpaid" % Game.unpaid_count()) if Game.unpaid_count() > 0 else ""]   # economy: men the purse could not pay
	lbl_contract.text = Contracts.status_text(Game)
	var lg: Array = Game.world.get("log", [])
	lbl_log.text = "\n".join(lg.slice(maxi(0, lg.size() - 4)))
	lbl_news.text = Diplomacy.ticker(Game)   # diplomacy: latest declaration for a few days, "" otherwise
	btn_wait.text = "Stop" if Game.world["party"].get("waiting", false) else "Wait"
	if sites != null:
		sites.sync(Game)
	if info_panel.visible:
		_fill_info()

func toast(text: String) -> void:
	lbl_toast.text = text
	lbl_toast.visible = true
	_toast_t = 2.5

func _on_wait() -> void:
	var party: Dictionary = Game.world["party"]
	party["waiting"] = not party.get("waiting", false)
	_refresh_hud()

func _on_speed() -> void:
	speed_mult = {1: 2, 2: 4, 4: 1}[speed_mult]
	btn_speed.text = "x%d" % speed_mult

func _on_center() -> void:
	follow = true

func _on_save() -> void:
	Game.save_game_async()   # written by a worker thread (core/game.gd): no freeze on a Large world
	toast("Game saved.")

# ---------------------------------------------------------------- info panel
func _select(sel: Dictionary) -> void:
	selected = sel
	if sel.get("kind", "") != "track":
		tracks_layer.clear_selection()   # tracks
	info_panel.visible = true
	_fill_info()

func _close_info() -> void:
	selected = {}
	_info_key = ""
	info_panel.visible = false
	tracks_layer.clear_selection()

var _info_key := ""

func _fill_info() -> void:
	var w: Dictionary = Game.world
	var near := false
	if selected.get("kind", "") == "warband" and w["warbands"].has(selected["id"]):
		near = (w["warbands"][selected["id"]]["pos"] as Vector2).distance_to(w["party"]["pos"]) < 60.0
	# rebuild buttons only when the selection (or attack range) changes, never under the finger
	var key := "%s|%s|%s" % [selected.get("kind", ""), selected.get("id", ""), near]
	var rebuild := key != _info_key
	_info_key = key
	if rebuild:
		for c in info_buttons.get_children():
			c.queue_free()
	if selected.get("kind", "") == "warband":
		var rep := CampaignWorld.scout_report(Game, selected["id"])
		if rep.is_empty() or not icons.has(selected["id"]):
			_close_info(); return
		info_title.text = rep["kind_text"].capitalize()
		var wb: Dictionary = w["warbands"][selected["id"]]
		var extra := ""
		if wb["kind"] == "caravan":
			extra = "\nCarrying: %s\nBound for: %s" % [rep["cargo_text"], w["towns"].get(wb["dest"], {}).get("name", "?")]
			if wb.get("escort", "") != "" and Game.contract.get("target_id", "") == wb["id"]:
				extra += "\nYou are escorting it."
		elif rep["is_contract_target"]:
			extra = "\nThis is your contract target."
		info_body.text = "%s\nNumbers: %s\nGear: %s\nThey look %s.\nDisposition: %s%s" % [rep["home_text"].capitalize(), rep["count_text"],
			rep["gear_text"], rep["strength_text"], rep["disposition"], extra]
		var bl := ArmyPanel.band_line(wb)   # economy spec 2: officers, stores, unpaid men
		if bl != "":
			info_body.text += "\n" + bl
		var wm := WarAI.mode_text(wb)   # war interception: what the band is up to (text only)
		if wm != "":
			info_body.text += "\nAt war: " + wm + "."
		var wid: String = selected["id"]
		if not rebuild:
			return
		if Army.is_field(wb):
			var fid0: String = wb["faction"]
			info_buttons.add_child(_button("Ranks", func(): ArmyPanel.open(modal_host, fid0)))
		if near and wb["kind"] == "caravan":
			if Caravans.can_raid(Game, wid):
				# raiding costs heavy reputation with the caravan's faction
				info_buttons.add_child(_button("Raid", func(): _close_info(); CampaignWorld.engage(Game, wid)))
		elif near:
			info_buttons.add_child(_button("Attack", func(): _close_info(); CampaignWorld.engage(Game, wid)))
		else:
			info_buttons.add_child(_button("Pursue", func(): pursue_wid = wid; follow = true))
		info_buttons.add_child(_button("Close", _close_info))
	elif selected.get("kind", "") == "town":
		var t: Dictionary = w["towns"].get(selected["id"], {})
		if t.is_empty():
			_close_info(); return
		info_title.text = t["name"]
		var cr: Dictionary = t["crafters"]
		var st := Diplomacy.standing(Game, t["faction"])   # diplomacy: standing decides the offers you see
		info_body.text = "%s\nWeaponsmith: %s\nArmorsmith: %s\nContracts on offer: %d\nYour standing: %s (%+d)" % [Economy.describe_town(t),
			Economy.describe_crafter(cr["weaponsmith"]), Economy.describe_crafter(cr["armorsmith"]), Contracts.offers_for(Game, t).size(),
			Diplomacy.standing_word(st), st]
		if rebuild:
			var rtid: String = selected["id"]   # the records screen: this town, its faction, the world
			info_buttons.add_child(_button("Records", func(): Game.goto("res://ui/records.tscn", {"view": "town", "id": rtid, "back": "map"})))
			info_buttons.add_child(_button("Close", _close_info))
	elif selected.get("kind", "") == "track":
		tracks_layer.fill_info(self, rebuild)   # tracks

# ---------------------------------------------------------------- encounter
func _show_encounter(wid: String) -> void:
	if wid == "":
		enc_panel.visible = false
		return
	if enc_panel.visible:
		return
	_close_info()
	pursue_wid = ""
	var rep := CampaignWorld.scout_report(Game, wid)
	enc_title.text = rep.get("title", "%s %s!" % [rep["faction_name"], rep["kind_text"]])
	var wb: Dictionary = Game.world["warbands"][wid]
	var where := CampaignWorld.terrain_at(Game.world, Game.world["party"]["pos"])
	Game.world["party"]["waiting"] = false
	enc_body.text = "Enemy: %s, %s\nGear: %s\nThey look %s.\nGround: %s%s" % [
		String(DB.races[rep["race"]]["plural"]).capitalize(), rep["count_text"], rep["gear_text"], rep["strength_text"], where,
		"\nThis is your contract target." if rep["is_contract_target"] else
			("\nThey are falling on the caravan you escort; its guards will fight beside you." if wb.has("escort_fight") else "")]
	var fit: int = Game.deployed_units().size()
	enc_fight.disabled = fit == 0
	if fit == 0:
		enc_body.text += "\nNo one in the company is fit to fight. You must retreat."
	else:
		enc_body.text += "\n%d fit to fight." % fit
	enc_panel.visible = true

func _on_fight() -> void:
	if Game.deployed_units().is_empty():
		return
	var wid: String = Game.world.get("encounter", "")
	enc_panel.visible = false
	if wid != "":
		CampaignWorld.engage(Game, wid)

func _on_retreat() -> void:
	var wid: String = Game.world.get("encounter", "")
	enc_panel.visible = false
	CampaignWorld.retreat(Game, wid)
	toast("The company falls back.")
