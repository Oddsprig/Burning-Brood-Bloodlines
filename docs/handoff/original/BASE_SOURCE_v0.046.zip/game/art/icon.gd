class_name GameIcon
extends RefCounted
## The game icon, drawn in code: a copper sword crossed with a company banner on a dark shield-
## shaped plaque. Designed on a 32x32 grid; sizes that are multiples of 32 are upscaled with
## nearest filtering (crisp pixels), other sizes are rasterised directly at that size.
## No autoload access, so it also works from a bare `-s` script (art/make_icon.gd).

const PixelCanvasScript := preload("res://art/pixel_canvas.gd")

static func make_icon_image(size: int) -> Image:
	if size % 32 == 0:
		var img := _draw(32, 1.0)
		if size != 32:
			img.resize(size, size, Image.INTERPOLATE_NEAREST)
		return img
	return _draw(size, size / 32.0)

static func _ol(c: Color) -> Color:
	return c.darkened(0.72).lerp(Color("#140a10"), 0.45)

static func _draw(px: int, k: float) -> Image:
	var cv = PixelCanvasScript.new(px, px)
	cv.set_frame(Vector2.ZERO, k, 0.0)
	# plaque
	var bg_top := Color("#3a2440")
	var bg_bot := Color("#1c1426")
	cv.begin()
	cv.poly(PackedVector2Array([Vector2(3, 1), Vector2(29, 1), Vector2(31, 3), Vector2(31, 20), Vector2(16, 31),
		Vector2(1, 20), Vector2(1, 3)]), bg_top, func(_x: int, y: int, _c: Color) -> Color:
		return bg_top.lerp(bg_bot, clampf(float(y) / px, 0.0, 1.0)))
	cv.end(Color("#0e080c"), 0.0)
	# copper rim
	var cu_light := Color("#f5a85a")
	cv.begin()
	cv.line1(Vector2(3, 2), Vector2(29, 2), cu_light)
	cv.end(Color(0, 0, 0, 0), 0.0)
	# banner pole + flag
	var wood := Color("#8a5a30")
	cv.begin()
	cv.capsule(Vector2(6.5, 26.5), Vector2(22.5, 5.0), 0.7, wood)
	cv.end(_ol(wood), 0.1)
	var teal := Color("#21a69d")
	var gold := Color("#f0b040")
	cv.begin()
	cv.poly(PackedVector2Array([Vector2(22.5, 5.0), Vector2(30.0, 6.0), Vector2(27.0, 10.5), Vector2(30.0, 15.5), Vector2(16.0, 14.0)]),
		teal, func(x: int, y: int, c: Color) -> Color:
			var u := (x + 0.5) / k
			var v := (y + 0.5) / k
			return gold if absf((v - 6.0) - (u - 22.0) * 0.08 - 3.0) < 0.75 else c)
	cv.end(_ol(teal), 0.14)
	cv.begin()
	cv.ellipse(Vector2(23.0, 4.5), 1.5, 1.5, Color("#d4742e"))
	cv.end(_ol(Color("#d4742e")), 0.16, Color("#ffe6b0"))
	# sword (tip top-left, hilt bottom-right)
	var cu := Color("#d4742e")
	cv.begin()
	cv.poly(PackedVector2Array([Vector2(5.0, 4.0), Vector2(9.5, 6.0), Vector2(22.5, 19.0), Vector2(20.0, 21.5),
		Vector2(7.0, 8.5)]), cu)
	cv.end(_ol(cu), 0.16, Color("#ffe6b0"))
	cv.begin()
	cv.line1(Vector2(7.5, 6.5), Vector2(20.0, 19.0), Color("#ffd690"))
	cv.end(Color(0, 0, 0, 0), 0.0)
	cv.begin()
	cv.capsule(Vector2(18.0, 24.5), Vector2(25.5, 17.0), 1.0, gold)
	cv.end(_ol(gold), 0.16, Color("#fff0c0"))
	cv.begin()
	cv.capsule(Vector2(22.5, 22.0), Vector2(25.5, 25.0), 0.9, Color("#5a3420"))
	cv.end(_ol(Color("#5a3420")), 0.1)
	cv.begin()
	cv.ellipse(Vector2(26.8, 26.3), 1.6, 1.6, gold)
	cv.end(_ol(gold), 0.16, Color("#fff0c0"))
	return cv.to_image()
