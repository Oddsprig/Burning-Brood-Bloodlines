extends Node2D
## Draws the battle ground from sim.tile_at(cell) ("open" | "rough" | "blocked"): terrain-coloured tiles with
## per-tile variation and small decorations, rough ground as darker scrub/stones, blocked tiles as trees, rocks
## or water depending on terrain, plus a darker margin beyond the map edge. Purely visual.

const PALETTES := {
	"plains": {"base": Color("#6fae3c"), "alt": Color("#64a136"), "deco": Color("#4f8a2a"), "stone": Color("#9a9a8c"), "edge": Color("#3d5e24"), "block": "rock"},
	"forest": {"base": Color("#4f8f35"), "alt": Color("#47832f"), "deco": Color("#2f6a24"), "stone": Color("#7d7a6c"), "edge": Color("#24401a"), "block": "tree"},
	"silverwood": {"base": Color("#5f9c6a"), "alt": Color("#56915f"), "deco": Color("#3d7a52"), "stone": Color("#a8b4b0"), "edge": Color("#2c4a38"), "block": "silvertree"},
	"hills": {"base": Color("#8aa84a"), "alt": Color("#7f9c43"), "deco": Color("#647f32"), "stone": Color("#9d958a"), "edge": Color("#4f5e2c"), "block": "rock"},
	"mountains": {"base": Color("#9a9a84"), "alt": Color("#8f8f7a"), "deco": Color("#707060"), "stone": Color("#b0aca2"), "edge": Color("#55554a"), "block": "rock"},
	"badlands": {"base": Color("#c79a5e"), "alt": Color("#bd9055"), "deco": Color("#9a7040"), "stone": Color("#a07a58"), "edge": Color("#6e4e2c"), "block": "rock"},
	"snow": {"base": Color("#e6eef4"), "alt": Color("#d9e4ec"), "deco": Color("#b9c8d4"), "stone": Color("#8a96a0"), "edge": Color("#7f93a3"), "block": "rock"},
	"marsh": {"base": Color("#5d7f4a"), "alt": Color("#557444"), "deco": Color("#3f5e4a"), "stone": Color("#6d6f5c"), "edge": Color("#2e3f2a"), "block": "water"},
	"road": {"base": Color("#7fae48"), "alt": Color("#76a342"), "deco": Color("#5e8a32"), "stone": Color("#a89a7c"), "edge": Color("#41602a"), "block": "rock"},
}
const ALIASES := {"grassland": "plains", "mud": "marsh", "swamp": "marsh", "desert": "badlands"}

var sim
var grid_w := 32
var grid_h := 18
var tile := 40.0
var terrain := "plains"
var seed_value := 1
var margin := 120.0

func configure(battle_sim, tile_px: float, terrain_id: String, s: int) -> void:
	sim = battle_sim
	grid_w = sim.grid_w; grid_h = sim.grid_h; tile = tile_px
	terrain = ALIASES.get(terrain_id, terrain_id)
	seed_value = s
	queue_redraw()

func _tile(x: int, y: int) -> String:
	return sim.tile_at(Vector2i(x, y)) if sim != null else "open"

func _draw() -> void:
	var pal: Dictionary = PALETTES.get(terrain, PALETTES["plains"])
	var size := Vector2(grid_w * tile, grid_h * tile)
	draw_rect(Rect2(-Vector2(margin, margin), size + Vector2(margin, margin) * 2.0), pal["edge"])
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_value
	var blocked := []
	for y in grid_h:
		for x in grid_w:
			var c: Color = pal["base"] if (x + y) % 2 == 0 else pal["alt"]
			c = c.lightened(rng.randf_range(-0.03, 0.04))
			var kind := _tile(x, y)
			var r := Rect2(x * tile, y * tile, tile, tile)
			if kind == "rough":
				c = c.darkened(0.16).lerp(pal["stone"], 0.12)
			draw_rect(r, c)
			if kind == "rough":
				for i in 4:
					var p := r.position + Vector2(rng.randf_range(5, tile - 5), rng.randf_range(8, tile - 3))
					if rng.randf() < 0.5:
						draw_circle(p, rng.randf_range(2.0, 3.5), pal["stone"].darkened(0.1))
					else:
						for j in 3:
							draw_line(p + Vector2((j - 1) * 3.0, 0), p + Vector2((j - 1) * 4.5, -6 - rng.randf() * 3), pal["deco"].darkened(0.15), 1.5)
			elif kind == "blocked":
				blocked.append(Vector2i(x, y))
	var gl: Color = pal["deco"]; gl.a = 0.18
	for x in grid_w + 1:
		draw_line(Vector2(x * tile, 0), Vector2(x * tile, size.y), gl, 1.0)
	for y in grid_h + 1:
		draw_line(Vector2(0, y * tile), Vector2(size.x, y * tile), gl, 1.0)
	var n := grid_w * grid_h / 3
	for i in n:
		var p := Vector2(rng.randf() * size.x, rng.randf() * size.y)
		var k := rng.randf()
		var cell := Vector2i(int(p.x / tile), int(p.y / tile))
		if _tile(cell.x, cell.y) != "open":
			continue
		if k < 0.6:
			for j in 3:
				var dx := (j - 1) * 3.0
				draw_line(p + Vector2(dx, 0), p + Vector2(dx * 1.6, -5 - rng.randf() * 3), pal["deco"], 1.5)
		elif k < 0.85:
			draw_circle(p, 2.0 + rng.randf() * 2.5, pal["stone"])
		else:
			draw_circle(p, 2.0, Color("#f3e36b") if rng.randf() < 0.5 else Color("#f08ab0"))
	# blocked tiles last so tree crowns overlap the row above
	for b in blocked:
		_draw_blocked(Rect2(b.x * tile, b.y * tile, tile, tile), pal, rng)
	draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, 0.35), false, 3.0)

func _draw_blocked(r: Rect2, pal: Dictionary, rng: RandomNumberGenerator) -> void:
	var ctr := r.get_center()
	match str(pal["block"]):
		"tree", "silvertree":
			var crown: Color = Color("#2e6b2a") if pal["block"] == "tree" else Color("#9fd0c0")
			var trunk: Color = Color("#5a3a1e") if pal["block"] == "tree" else Color("#d8dcd6")
			draw_set_transform(ctr + Vector2(0, tile * 0.38), 0.0, Vector2(1.0, 0.35))
			draw_circle(Vector2.ZERO, tile * 0.42, Color(0, 0, 0, 0.3))
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
			draw_rect(Rect2(ctr + Vector2(-3, 0), Vector2(6, tile * 0.42)), trunk)
			draw_circle(ctr + Vector2(0, -tile * 0.12), tile * 0.42, crown.darkened(0.2))
			draw_circle(ctr + Vector2(-tile * 0.1, -tile * 0.2), tile * 0.3, crown)
			draw_circle(ctr + Vector2(tile * 0.12, -tile * 0.3), tile * 0.16, crown.lightened(0.18))
		"water":
			draw_rect(r.grow(-1), Color("#3f6f8a"))
			draw_line(ctr + Vector2(-10, -4), ctr + Vector2(6, -4), Color("#8fc0d8"), 2.0)
			draw_line(ctr + Vector2(-4, 6), ctr + Vector2(10, 6), Color("#8fc0d8"), 2.0)
		_:
			var sc := rng.randf_range(0.85, 1.05)
			var pts := PackedVector2Array()
			for i in 7:
				var a := TAU * i / 7.0
				pts.append(ctr + Vector2(cos(a), sin(a) * 0.75) * tile * 0.45 * sc * rng.randf_range(0.8, 1.1) + Vector2(0, 3))
			draw_colored_polygon(pts, Color(pal["stone"]).darkened(0.2))
			draw_circle(ctr + Vector2(-tile * 0.08, -tile * 0.08), tile * 0.16, Color(pal["stone"]).lightened(0.15))
