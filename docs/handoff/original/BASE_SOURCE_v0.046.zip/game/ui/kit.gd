class_name UiKit
extends RefCounted
## Small builders for the menu screens (code-built Control trees) plus modal picker / confirm / toast.

const TAP := 52  # minimum control height (phone tap target >= 48 px)

static func label(text: String, variation: String = "", wrap: bool = false) -> Label:
	var l := Label.new()
	l.text = text
	if variation != "":
		l.theme_type_variation = variation
	if wrap:
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l

static func button(text: String, cb: Callable, variation: String = "", min_w: int = 0) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(min_w, TAP)
	if variation != "":
		b.theme_type_variation = variation
	b.focus_mode = Control.FOCUS_NONE
	b.pressed.connect(cb)
	return b

static func hbox(sep: int = 8) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", sep)
	return h

static func vbox(sep: int = 8) -> VBoxContainer:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", sep)
	return v

static func panel(variation: String = "") -> PanelContainer:
	var p := PanelContainer.new()
	if variation != "":
		p.theme_type_variation = variation
	return p

static func scroll() -> ScrollContainer:
	var s := ScrollContainer.new()
	s.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	s.size_flags_vertical = Control.SIZE_EXPAND_FILL
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return s

static func spacer() -> Control:
	var c := Control.new()
	c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return c

static func expand(c: Control, h: bool = true, v: bool = false) -> Control:
	if h:
		c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	if v:
		c.size_flags_vertical = Control.SIZE_EXPAND_FILL
	return c

static func clear(n: Node) -> void:
	for c in n.get_children():
		n.remove_child(c)
		c.queue_free()

## Coloured badge with text (faction chips, status tags).
static func chip(text: String, bg: Color, fg: Color = UiTheme.LIGHT) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", UiTheme.sb(bg, bg.darkened(0.35), 2, 12, 10, 3))
	var l := Label.new()
	l.text = text
	l.add_theme_color_override("font_color", fg)
	l.add_theme_font_override("font", UiTheme.bold())
	l.add_theme_font_size_override("font_size", 18)
	p.add_child(l)
	return p

## An item / goods icon (art/item_icon.gd) at px, crisp pixels, centred in its row.
static func icon(tex: Texture2D, px: int = 40) -> TextureRect:
	var r := TextureRect.new()
	r.texture = tex
	r.custom_minimum_size = Vector2(px, px)
	r.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	r.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	r.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	r.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return r

## A label + value line, value right-aligned.
static func kv(key: String, value: String, value_color: Color = UiTheme.INK) -> HBoxContainer:
	var h := hbox()
	var k := label(key, "Muted")
	h.add_child(k)
	h.add_child(spacer())
	var v := label(value)
	v.add_theme_color_override("font_color", value_color)
	h.add_child(v)
	return h

## Tab strip of big buttons. Returns the HBox; cb(name) on tap.
## Tabs share the row and shrink (ellipsis) when the window is narrow; never wider than their parent.
static func tab_strip(names: Array, current: String, cb: Callable) -> HBoxContainer:
	var h := hbox(6)
	h.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for n in names:
		var b := button(String(n), cb.bind(n), "TabOn" if n == current else "Tab", 0)
		b.custom_minimum_size = Vector2(72, 56)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		h.add_child(b)
	return h

## A row that wraps onto the next line instead of growing past the window.
static func flow(sep: int = 8) -> HFlowContainer:
	var f := HFlowContainer.new()
	f.add_theme_constant_override("h_separation", sep)
	f.add_theme_constant_override("v_separation", 6)
	f.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return f

## Wrapping label that fills its row and never forces its parent wider than min_w.
static func wrap(l: Label, min_w: float = 60.0) -> Label:
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	l.custom_minimum_size.x = min_w
	return l

## Puts a side column in a vertical scroller (same width) so a tall column never pushes the screen taller.
static func scroll_column(col: Control) -> ScrollContainer:
	var sc := scroll()
	sc.size_flags_horizontal = Control.SIZE_FILL
	sc.custom_minimum_size.x = col.custom_minimum_size.x
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(col)
	return sc

## Make a label (or button) give up width gracefully: fills its row, trims with an ellipsis.
static func shrink(c: Control, min_w: float = 40.0) -> Control:
	c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	c.custom_minimum_size.x = min_w
	if c is Label:
		(c as Label).text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	elif c is Button:
		(c as Button).text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	return c

## Full-screen modal layer with a dimmed backdrop and a centred parchment panel. Returns the content VBox.
static func modal(host: Control, title: String, width: int = 680) -> VBoxContainer:
	var layer := Control.new()
	layer.name = "Modal"
	# Found by meta, not by name: a second modal opened while the first is still being freed (picker -> message)
	# gets auto-renamed by Godot, and a name lookup then never finds it, so its OK button did nothing.
	layer.set_meta("ui_modal", true)
	layer.set_anchors_preset(Control.PRESET_FULL_RECT)
	layer.mouse_filter = Control.MOUSE_FILTER_STOP
	var dim := ColorRect.new()
	dim.color = Color(0.05, 0.03, 0.01, 0.7)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	layer.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	layer.add_child(center)
	var p := panel()
	p.custom_minimum_size = Vector2(width, 0)
	center.add_child(p)
	var v := vbox(10)
	p.add_child(v)
	var t := label(title, "H2", true)
	v.add_child(t)
	v.add_child(HSeparator.new())
	host.add_child(layer)
	return v

static func close_modal(from: Node) -> void:
	var n := from
	while n != null and not n.has_meta("ui_modal"):
		n = n.get_parent()
	if n != null:
		n.queue_free()

## Choice list. options = [{"text", "value", "disabled"?: bool, "detail"?: String, "icon"?: Texture2D}]. on_pick(value).
static func picker(host: Control, title: String, options: Array, on_pick: Callable, width: int = 680) -> void:
	var v := modal(host, title, width)
	var sc := scroll()
	sc.custom_minimum_size = Vector2(0, mini(70 * maxi(options.size(), 1), 470))
	v.add_child(sc)
	var list := vbox(6)
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(list)
	if options.is_empty():
		list.add_child(label("Nothing to choose from.", "Muted"))
	for o in options:
		var txt: String = o["text"]
		if o.get("detail", "") != "":
			txt += "   -   " + String(o["detail"])
		var b := button(txt, func():
			close_modal(v)
			on_pick.call(o["value"]), "Row")
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		if o.get("icon") is Texture2D:   # item icons (art/item_icon.gd)
			b.icon = o["icon"]
			b.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		b.disabled = bool(o.get("disabled", false))
		b.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		list.add_child(b)
	var row := hbox()
	row.add_child(spacer())
	row.add_child(button("Cancel", func(): close_modal(v), "", 160))
	v.add_child(row)

static func confirm(host: Control, text: String, yes_text: String, on_yes: Callable) -> void:
	var v := modal(host, text, 560)
	var row := hbox()
	row.add_child(spacer())
	row.add_child(button("Cancel", func(): close_modal(v), "Row", 160))
	row.add_child(button(yes_text, func():
		close_modal(v)
		on_yes.call(), "Danger", 160))
	v.add_child(row)

## Message panel for longer reports (e.g. missing uniform pieces).
static func message(host: Control, title: String, lines: Array) -> void:
	var v := modal(host, title, 640)
	var sc := scroll()
	var rows := 0
	for l in lines:
		rows += 1 + String(l).length() / 52
	sc.custom_minimum_size = Vector2(0, mini(32 * maxi(rows, 1) + 16, 440))
	v.add_child(sc)
	var list := vbox(4)
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(list)
	for l in lines:
		list.add_child(label(String(l), "", true))
	var row := hbox()
	row.add_child(spacer())
	row.add_child(button("OK", func(): close_modal(v), "", 160))
	v.add_child(row)

## Short message that floats at the bottom of the host and fades.
static func toast(host: Control, text: String, good: bool = true) -> void:
	var old := host.get_node_or_null("Toast")
	if old != null:
		old.name = "ToastOld"
		old.queue_free()
	var p := PanelContainer.new()
	p.name = "Toast"
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var bg := UiTheme.GOOD if good else UiTheme.BAD
	p.add_theme_stylebox_override("panel", UiTheme.sb(bg.darkened(0.1), Color("1a0f08"), 2, 10, 18, 10))
	var l := Label.new()
	l.text = text
	l.add_theme_color_override("font_color", UiTheme.LIGHT)
	l.add_theme_font_override("font", UiTheme.bold())
	p.add_child(l)
	p.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	p.grow_horizontal = Control.GROW_DIRECTION_BOTH
	p.grow_vertical = Control.GROW_DIRECTION_BEGIN
	p.offset_bottom = -24
	host.add_child(p)
	if host.is_inside_tree():
		var tw := p.create_tween()
		tw.tween_interval(2.2)
		tw.tween_property(p, "modulate:a", 0.0, 0.6)
		tw.tween_callback(p.queue_free)

## Settings button for any HUD. as_overlay = true opens settings.tscn as a child popup of `host` (use it in
## battle so the fight is not lost); otherwise switches to the "settings" screen and Back returns to `back`.
static func settings_button(host: Control, back: String = "", as_overlay: bool = false) -> Button:
	return button("Settings", func(): open_settings(host, back, as_overlay), "Row", 130)

static func open_settings(host: Node, back: String = "", as_overlay: bool = false) -> void:
	if as_overlay:
		var s = load("res://ui/settings.tscn").instantiate()
		s.overlay = true
		host.add_child(s)
	else:
		Game.goto("settings", {"back": back})

## Portrait in a framed box.
static func portrait(u: Unit, px: int) -> Control:
	var frame := PanelContainer.new()
	frame.add_theme_stylebox_override("panel", UiTheme.sb(UiTheme.WOOD_2, UiTheme.BRASS.darkened(0.3), 3, 6, 3, 3))
	var p := Portrait.new()
	p.custom_minimum_size = Vector2(px, px)
	p.set_unit(u)
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	frame.add_child(p)
	frame.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return frame

## Standard screen backdrop + top bar. Returns {"root": VBox content area, "bar": HBox in the top bar}.
static func screen_frame(host: Control, title: String) -> Dictionary:
	host.theme = UiTheme.get_theme()
	host.set_anchors_preset(Control.PRESET_FULL_RECT)
	var bg := WoodBg.new()
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	host.add_child(bg)
	var outer := vbox(0)
	outer.set_anchors_preset(Control.PRESET_FULL_RECT)
	host.add_child(outer)
	var bar_p := panel("Bar")
	bar_p.custom_minimum_size = Vector2(0, 68)
	outer.add_child(bar_p)
	var bar := hbox(10)
	bar_p.add_child(bar)
	var t := label(title, "Header")
	t.name = "Title"
	var tw := t.get_minimum_size().x
	t.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	t.custom_minimum_size.x = minf(tw, 220)
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	t.size_flags_stretch_ratio = 1.5
	t.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	bar.add_child(t)
	var m := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		m.add_theme_constant_override("margin_" + side, 12)
	m.size_flags_vertical = Control.SIZE_EXPAND_FILL
	outer.add_child(m)
	var root := vbox(10)
	m.add_child(root)
	return {"root": root, "bar": bar, "title": t}

## Gold and day readout for top bars.
static func purse_text(game) -> String:
	var unpaid: int = game.unpaid_count() if game.has_method("unpaid_count") else 0
	return "Day %d   %s coins   wages %s/day%s" % [int(game.day) + 1, thousands(int(game.gold)), thousands(int(game.daily_wages())),
		("   %d men unpaid" % unpaid) if unpaid > 0 else ""]

## 1234567 -> "1,234,567".
static func thousands(n: int) -> String:
	var s := str(absi(n))
	var out := ""
	while s.length() > 3:
		out = "," + s.substr(s.length() - 3) + out
		s = s.substr(0, s.length() - 3)
	return ("-" if n < 0 else "") + s + out

static func purse(game) -> Label:
	var l := label(purse_text(game), "Header")
	l.add_theme_font_size_override("font_size", 22)
	l.add_theme_color_override("font_color", UiTheme.BRASS)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	# never cut the coins off (Douglas: "we should be able to see at least a million coins"): the line wraps onto a
	# second row when the bar is narrow instead of ending in "..."
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	l.custom_minimum_size.x = 120
	l.text_overrun_behavior = TextServer.OVERRUN_NO_TRIMMING
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l
