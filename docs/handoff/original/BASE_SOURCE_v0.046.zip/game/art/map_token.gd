class_name MapToken
extends Node2D
## One campaign-map token (docs/specs/map-tokens.md): draws a cached MapTokens texture with the box point
## (32,55) on the node's position. The node's scale is world units per box unit (MapTokens.box_unit(zoom)).
## Static: no _process, redraws only when its texture key changes.
##   var t := MapToken.new(); t.set_texture(MapTokens.key(...), MapTokens.texture(...))
##   t.refresh(game, warband)   # recompute type / faction / pips / stance from the warband

var key := ""
var tex: Texture2D
var seen := 0        # MapTokens.sync frame stamp
var count := 0       # headcount behind the current texture

const _RECT := Rect2(-MapTokens.PAD - MapTokens.ANCHOR.x, -MapTokens.PAD - MapTokens.ANCHOR.y,
	MapTokens.BOX + 2.0 * MapTokens.PAD, MapTokens.BOX + 2.0 * MapTokens.PAD)

func _init() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS

func set_texture(k: String, t: Texture2D) -> void:
	if k == key:
		return
	key = k
	tex = t
	queue_redraw()

func refresh(game, wb: Dictionary) -> void:
	var tk := MapTokens.token_key_for(game, wb)
	count = tk[4]
	visible = count > 0 or wb.get("kind", "") != "militia"   # a wiped-out militia leaves no token
	var k := MapTokens.key(tk[0], tk[1], tk[2], tk[3])
	if k != key:
		set_texture(k, MapTokens.texture(tk[0], tk[1], tk[2], tk[3]))

func _draw() -> void:
	if tex != null:
		draw_texture_rect(tex, _RECT, false)
