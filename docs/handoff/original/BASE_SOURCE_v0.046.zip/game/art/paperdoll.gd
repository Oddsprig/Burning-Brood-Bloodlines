class_name Paperdoll
extends Node2D
## A layered unit sprite drawn in code: race base body + outer clothing/armor + helm + weapon
## (+ shield) + wound overlay. Bright, saturated faction colours; per-individual skin shade from unit.look.
## Origin is at the feet. Nominal height ~48 px for a human at scale 1 (24 logical pixels at 2x).
##
##   var d := Paperdoll.new(); d.set_unit(unit); add_child(d)
##   d.set_pose("idle"|"walk"|"prepare"|"strike"|"recover"|"hit"|"block"|"dodge"|"prone"|"dead", progress 0..1)
##   d.facing = 1 or -1
##   d.refresh()  # after equipment or wounds change
##   d.team_color = Color   # ring / banner tint so sides read at a glance
##
## Frames are rendered by FigurePainter into small ImageTextures and cached (shared by all dolls),
## keyed by the unit's look/gear/wound signature + pose + frame, so a battle of many units mostly
## reuses textures. idle and walk loop with progress (0..1 = one cycle); the other poses map
## progress 0..1 onto their few key frames.

const CACHE_LIMIT := 1500
static var _cache: Dictionary = {}

var unit: Unit
var facing: int = 1:
	set(v):
		facing = -1 if v < 0 else 1
		queue_redraw()
var pose: String = "idle"
var progress: float = 0.0
var team_color := Color.WHITE:
	set(v):
		if v != team_color:
			team_color = v
			_dirty = true
			queue_redraw()

## bows: the unit has his bow in his hands (battle): the bow is drawn instead of the sidearm, the shield is slung.
var bow_hand := false:
	set(v):
		if v != bow_hand:
			bow_hand = v
			_dirty = true
			_frame_key = ""
			queue_redraw()

var _spec: Dictionary = {}
var _sig: int = 0
var _dirty := true
var _tex: Texture2D
var _frame_key := ""
var _anchor := Vector2.ZERO

func set_unit(u: Unit) -> void:
	unit = u
	refresh()

## Draw from a ready-made spec instead of a Unit (previews, party icons).
func set_spec(s: Dictionary) -> void:
	unit = null
	_spec = s
	_spec["team"] = team_color
	_sig = _spec.hash()
	_dirty = false
	_frame_key = ""
	_update_tex()
	queue_redraw()

func set_pose(p: String, t: float = 0.0) -> void:
	pose = p if FigurePainter.FRAMES.has(p) else "idle"
	progress = t
	_update_tex()
	queue_redraw()

func refresh() -> void:
	_dirty = true
	_frame_key = ""
	_rebuild_spec()
	_update_tex()
	queue_redraw()

func _rebuild_spec() -> void:
	if unit != null:
		_spec = FigurePainter.spec_for_unit(unit, team_color)
		if bow_hand and unit.bow() != null:   # bows
			_spec["weapon"] = FigurePainter._item_spec(unit.bow())
			_spec["shield"] = {}
			_spec["bow_hand"] = true
	elif not _spec.is_empty():
		_spec["team"] = team_color
	_sig = _spec.hash()
	_dirty = false

func current_spec() -> Dictionary:
	if _dirty:
		_rebuild_spec()
	return _spec

## Builds (or fetches) the texture for the current pose frame. Safe headless.
func _update_tex() -> void:
	if _dirty:
		_rebuild_spec()
	if _spec.is_empty():
		_tex = null
		return
	var f := FigurePainter.frame_index(pose, progress)
	var key := "%d|%s|%d" % [_sig, pose, f]
	if key == _frame_key and _tex != null:
		return
	_frame_key = key
	var dm := FigurePainter.dims(_spec.get("race", "human"))
	_anchor = dm["anchor"]
	if _cache.has(key):
		_tex = _cache[key]
		return
	if _cache.size() >= CACHE_LIMIT:
		_cache.clear()
	_tex = ImageTexture.create_from_image(build_image())
	_cache[key] = _tex

## The current frame as an Image (logical pixels; feet at FigurePainter.dims(race).anchor).
func build_image() -> Image:
	var sp := current_spec()
	return FigurePainter.render(sp, pose, FigurePainter.frame_t(pose, FigurePainter.frame_index(pose, progress)))

## A static ground decal of a lost body part (head with hair + helm, arm, forearm, hand, leg,
## shin, foot) in the unit's own skin/clothes, lying in a small blood splat. Origin = centre of
## the piece; drawn at the same 2x pixel scale as the doll. Battle spawns it at the unit's tile on
## a "sever" event. Unknown part ids give just the splat.
static func make_severed_piece(u: Unit, part_id: String) -> Node2D:
	var s := Sprite2D.new()
	s.name = "Severed_" + part_id
	s.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	if u != null:
		var sp := FigurePainter.spec_for_unit(u)
		# draw the piece itself even though the unit has now lost it
		var lost: Array = (sp.get("lost", []) as Array).duplicate()
		lost.erase(part_id)
		sp["lost"] = lost
		sp["dmg"] = {}
		s.texture = ImageTexture.create_from_image(FigurePainter.render_piece(sp, part_id))
	s.scale = Vector2(FigurePainter.PX, FigurePainter.PX)
	return s

static func clear_cache() -> void:
	_cache.clear()

func _draw() -> void:
	if _dirty or _tex == null:
		_update_tex()
	if _tex == null:
		return
	var mod := Color.WHITE
	if pose == "hit" and progress < 0.5:
		mod = Color(1.0, 0.62, 0.62)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(FigurePainter.PX * facing, FigurePainter.PX))
	draw_texture(_tex, -_anchor, mod)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
