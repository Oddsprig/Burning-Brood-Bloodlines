extends Node
## Root scene: hosts one screen at a time. Screens are switched with Game.goto("name").

var current: Node = null

## v0.014 (Douglas: "pretty long loading screen between menus"): the big screens' scenes (and the scripts behind
## them) load once per run, in the background while the title shows, and are kept here. Loaded on first use they
## cost 0.2-0.7 s each (town 0.5 s, records 0.7 s), and an unkept scene was read from disk again on every switch.
const WARM := ["res://campaign/world_map.tscn", "res://ui/town.tscn", "res://ui/company.tscn", "res://ui/records.tscn"]
var _scenes := {}     # path -> PackedScene
var _warming := {}    # path -> true while its background load is running

func _ready() -> void:
	Game.main = self
	if DisplayServer.get_name() != "headless":
		DisplayServer.set_icon(GameIcon.make_icon_image(256))
	get_window().title = "Copper Oath v%s" % String(ProjectSettings.get_setting("application/config/version", "?"))   # set by tools/release.sh
	Game.goto("title")
	for p in WARM:
		if ResourceLoader.exists(p) and ResourceLoader.load_threaded_request(p) == OK:
			_warming[p] = true

func _scene(path: String) -> PackedScene:
	if _scenes.has(path):
		return _scenes[path]
	var ps: PackedScene = null
	if _warming.has(path):
		_warming.erase(path)
		ps = ResourceLoader.load_threaded_get(path) as PackedScene   # waits if the background load is not done yet
	if ps == null:
		ps = load(path) as PackedScene
	_scenes[path] = ps
	return ps

func show_screen(path: String) -> void:
	if current != null:
		current.queue_free()
		current = null
	if not ResourceLoader.exists(path):
		push_error("Missing screen: " + path)
		var l := Label.new()
		l.text = "Screen not built yet: " + path
		current = l
		add_child(l)
		return
	current = _scene(path).instantiate()
	add_child(current)

## Collects background loads nobody asked for (quitting from the title), so none is left running.
func _exit_tree() -> void:
	for p in _warming:
		ResourceLoader.load_threaded_get(p)
	_warming.clear()
