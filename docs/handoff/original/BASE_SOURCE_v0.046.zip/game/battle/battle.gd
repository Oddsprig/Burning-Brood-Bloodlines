extends Node2D
## Battle screen. Builds the sim from Game.pending_battle, animates its ticks (it never drives game logic),
## and hands the result to Game.finish_battle when the sim is over.
##
## Reads only the BattleSim/Fighter contract (sim/battle_sim.gd, sim/fighter.gd): setup/step/is_over,
## tick, grid_w/h, tile_at, fighters, new_events, events, winner, event_text/render_entry; Fighter idx, unit,
## side, cell, prev_cell, facing, target, state, action_ticks, action_total, current_attack, log, prone,
## waiting, speed, wielded, weapon_dropped, bleeding. HealthReport.describe. Paperdoll (set_unit, set_pose,
## facing, team_color, refresh, make_severed_piece).
## Event convention (as the sim emits it): actor = attacker, target = defender for attack/miss/dodge/block/
## parry/hit/wound/artery/sever/death; single-unit events have target -1.

const MapView := preload("res://battle/map_view.gd")
const UnitView := preload("res://battle/unit_view.gd")
const FxLayer := preload("res://battle/fx_layer.gd")
const Inspector := preload("res://battle/inspector.gd")
const GoreLayer := preload("res://battle/gore_layer.gd")

const TICKS_PER_SEC := 20.0           # sim ticks per real second at 1x (1 tick = 0.05 s: 1x is real time)
const SPEEDS := [0.0, 1.0, 2.0, 4.0]
const SMALL_GRID := Vector2i(32, 18)  # one screen at 40 px
const LARGE_GRID := Vector2i(64, 36)  # 2x2 screens
const SMALL_MAX_PER_SIDE := 20
const TILE := 40.0
const MAP_MARGIN := 60.0
const MAX_ZOOM := 2.5
const SLOWMO_FACTOR := 0.22
const SLOWMO_TIME := 1.4              # real seconds
const SLOWMO_COOLDOWN := 2.5
const DRAG_THRESHOLD := 12.0
const FEED_MAX := 5
const FEED_LIFE := 10.0
const RESULT_DELAY := 1.2
## World-map terrain name -> sim terrain (movement multiplier key in Formulas.TERRAIN_MOVE) and map look.
const SIM_TERRAIN := {"grassland": "plains", "silverwood": "forest", "badlands": "plains", "mountains": "hills"}
## Share of the middle ground that is rough / blocked, per terrain (battle map dressing via the sim's "tiles" option).
const TERRAIN_DRESS := {"forest": [0.10, 0.05], "silverwood": [0.08, 0.05], "hills": [0.14, 0.03],
	"mountains": [0.14, 0.05], "badlands": [0.12, 0.02], "marsh": [0.18, 0.02], "grassland": [0.03, 0.0], "plains": [0.03, 0.0]}

var sim: BattleSim
var speed := 1.0
var paused := false
var views: Array = []                  # UnitView per fighter idx
var selected := -1
var side_names := ["Company", "Enemy"]
var terrain := "plains"
var finished := false
var result_shown := false
var _acc := 0.0
var _slowmo := 0.0
var _slowmo_cd := 0.0
var _over_timer := 0.0
var _skipping := false
var _settings_overlay: Node = null
var settings_open := false
var _paused_before_settings := false

# camera
var camera: Camera2D
var cam_pos := Vector2.ZERO
var cam_zoom := 1.0
var _nudge_target := Vector2.ZERO
var _nudge_amount := 0.0
var _nudge := 0.0
var _press_pos := Vector2.ZERO
var _pressing := false
var _dragging := false

# nodes
var map_view: Node2D
var units_layer: Node2D
var gore_layer: Node2D
var gore_pieces: Array = []          # {node, fighter, part} severed parts on the ground
var blood: Node2D                    # v0.014 GoreLayer: sprays, pools, trails (under the severed pieces and the units)
var fx: Node2D
var arrows_layer: ArrowLayer   # bows
var ui: Control
var speed_buttons: Array = []
var status_label: Label
var feed_box: VBoxContainer
var inspector: PanelContainer
var result_panel: PanelContainer

func _ready() -> void:
	var pb: Dictionary = Game.pending_battle
	if pb.is_empty():
		pb = _demo_battle()
	var side0: Array = Game.deployed_units() + pb.get("allies", [])
	var side1: Array = pb.get("enemy", [])
	var bseed: int = int(pb.get("seed", 1))
	terrain = str(pb.get("terrain", "plains"))
	if side1.size() > 0 and side1[0].faction != "":
		side_names[1] = str(DB.factions.get(side1[0].faction, {}).get("name", "Enemy"))
	sim = BattleSim.new()
	sim.setup(side0, side1, bseed, battle_opts(pb, side0.size(), side1.size()))
	speed = float(Game.setting("battle_speed")) if Game.setting("battle_speed") != null else 1.0
	if not speed in SPEEDS or speed <= 0.0:
		speed = 1.0
	_build_world(bseed)
	_build_ui()
	_fit_camera()
	_update_status()

## sim.setup options from a pending battle: grid size from unit counts (or "map": "small"/"large"), terrain,
## chokepoint ("choke": "corridor1"|"corridor2", or explicit "tiles" rows), "stream" arrival, and light
## terrain dressing (rough/blocked tiles in the middle ground; deploy columns stay open).
func battle_opts(pb: Dictionary, n0: int, n1: int) -> Dictionary:
	var per_side := maxi(n0, n1)
	var map_kind: String = str(pb.get("map", ""))
	var grid := SMALL_GRID
	if map_kind == "large" or per_side > SMALL_MAX_PER_SIDE:
		grid = LARGE_GRID
	var t := str(pb.get("terrain", "plains"))
	var opts := {"w": grid.x, "h": grid.y, "terrain": SIM_TERRAIN.get(t, t)}
	for k in ["stream", "stream_gap", "max_ticks", "corridor_len"]:
		if pb.has(k):
			opts[k] = pb[k]
	if pb.has("tiles"):
		opts["tiles"] = pb["tiles"]
	elif str(pb.get("choke", "")) != "":
		opts["map"] = str(pb["choke"])
	elif map_kind in ["corridor1", "corridor2"]:
		opts["map"] = map_kind
	else:
		opts["tiles"] = _dress_tiles(grid, t, int(pb.get("seed", 1)))
	return opts

func _dress_tiles(grid: Vector2i, t: String, s: int) -> Array:
	var d: Array = TERRAIN_DRESS.get(t, [0.05, 0.01])
	var rng := RandomNumberGenerator.new()
	rng.seed = s * 7919 + 13
	var cells := []
	for y in grid.y:
		var row := []
		row.resize(grid.x)
		row.fill(".")
		cells.append(row)
	# clumps: a seed tile plus a few neighbours, kept out of the deploy columns
	var keep := 9
	var area := (grid.x - keep * 2) * grid.y
	for kind in 2:
		var clumps := int(area * float(d[kind]) / 4.0)
		for i in clumps:
			var c := Vector2i(rng.randi_range(keep, grid.x - keep - 1), rng.randi_range(1, grid.y - 2))
			for j in rng.randi_range(2, 6):
				if c.x >= keep and c.x < grid.x - keep and c.y >= 0 and c.y < grid.y:
					if kind == 0 or cells[c.y][c.x] == ".":
						cells[c.y][c.x] = "," if kind == 0 else "#"
				c += Vector2i(rng.randi_range(-1, 1), rng.randi_range(-1, 1))
	var rows := []
	for row in cells:
		rows.append("".join(row))
	return rows

func _demo_battle() -> Dictionary:
	if Game.company.is_empty():
		Game.new_game(1234)
	var rng := RandomNumberGenerator.new(); rng.seed = 99
	return {"enemy": Factory.make_warband(rng, "orc_horde", 10), "allies": [], "seed": 5, "terrain": "grassland"}

# ------------------------------------------------------------------ world
func _build_world(map_seed: int) -> void:
	map_view = MapView.new()
	map_view.margin = MAP_MARGIN * 2.0
	map_view.configure(sim, TILE, terrain, map_seed)
	add_child(map_view)
	blood = GoreLayer.new()   # v0.014: sprays, pools, trails from the real wounds and bleeding
	blood.setup(TILE, Game.gore_full(), map_seed)
	add_child(blood)
	gore_layer = Node2D.new()
	add_child(gore_layer)
	units_layer = Node2D.new()
	units_layer.y_sort_enabled = true
	add_child(units_layer)
	for f in sim.fighters:
		var v := UnitView.new()
		v.setup(f, TILE)
		units_layer.add_child(v)
		views.append(v)
	arrows_layer = ArrowLayer.new()   # bows: arrows in flight
	arrows_layer.z_index = 5
	arrows_layer.setup(sim, TILE)
	add_child(arrows_layer)
	fx = FxLayer.new()
	fx.z_index = 10
	add_child(fx)
	camera = Camera2D.new()
	add_child(camera)
	camera.make_current()


func map_size() -> Vector2:
	return Vector2(sim.grid_w * TILE, sim.grid_h * TILE)

# ------------------------------------------------------------------ UI
func _build_ui() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 5
	add_child(layer)
	ui = Control.new()
	ui.set_anchors_preset(Control.PRESET_FULL_RECT)
	ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var th := Theme.new()
	th.default_font_size = 20
	ui.theme = th
	layer.add_child(ui)
	# top bar: playback controls + status
	var bar := HBoxContainer.new()
	bar.position = Vector2(10, 8)
	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bar.add_theme_constant_override("separation", 6)
	ui.add_child(bar)
	var labels := ["||", "1x", "2x", "4x"]
	for i in labels.size():
		var b := _big_button(labels[i], Vector2(68, 56))
		b.toggle_mode = true
		var s: float = SPEEDS[i]
		b.pressed.connect(func(): set_speed(s))
		bar.add_child(b)
		speed_buttons.append(b)
	var sk := _big_button("Skip >>|", Vector2(120, 56))
	sk.pressed.connect(skip_to_end)
	bar.add_child(sk)
	# settings (gear) as an overlay; playback pauses while it is open
	var gear: Button = UiKit.settings_button(ui, "", true)
	gear.custom_minimum_size = Vector2(120, 56)
	gear.pressed.connect(_on_settings_opened)   # connected after UiKit's, so the overlay already exists
	bar.add_child(gear)
	var sp := PanelContainer.new()
	sp.mouse_filter = Control.MOUSE_FILTER_IGNORE
	sp.add_theme_stylebox_override("panel", _box(Color(0, 0, 0, 0.55), 8))
	bar.add_child(sp)
	status_label = Label.new()
	status_label.add_theme_font_size_override("font_size", 18)
	status_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	status_label.custom_minimum_size = Vector2(0, 40)
	sp.add_child(status_label)
	# decisive-moment feed
	feed_box = VBoxContainer.new()
	feed_box.position = Vector2(10, 74)
	feed_box.custom_minimum_size = Vector2(500, 0)
	feed_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	feed_box.add_theme_constant_override("separation", 4)
	ui.add_child(feed_box)
	# inspector
	inspector = Inspector.new()
	inspector.anchor_left = 1.0; inspector.anchor_right = 1.0
	inspector.anchor_top = 0.0; inspector.anchor_bottom = 1.0
	inspector.offset_left = -Inspector.WIDTH; inspector.offset_right = 0
	inspector.offset_top = 0; inspector.offset_bottom = 0
	inspector.visible = false
	inspector.closed.connect(func(): select(-1))
	ui.add_child(inspector)
	_refresh_speed_buttons()

func _big_button(text: String, min_size: Vector2) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = min_size
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_stylebox_override("normal", _box(Color(0.12, 0.1, 0.09, 0.85), 6))
	b.add_theme_stylebox_override("hover", _box(Color(0.2, 0.17, 0.14, 0.9), 6))
	b.add_theme_stylebox_override("pressed", _box(Color(0.85, 0.6, 0.2, 0.95), 6))
	b.add_theme_stylebox_override("hover_pressed", _box(Color(0.92, 0.68, 0.25, 0.95), 6))
	b.add_theme_color_override("font_pressed_color", Color(0.1, 0.06, 0.02))
	b.add_theme_color_override("font_hover_pressed_color", Color(0.1, 0.06, 0.02))
	return b

func _box(c: Color, margin: int) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = c
	sb.set_corner_radius_all(6)
	sb.set_content_margin_all(margin)
	return sb

func _on_settings_opened() -> void:
	var last := ui.get_child(ui.get_child_count() - 1)
	if last == inspector or last == feed_box:
		return
	_settings_overlay = last
	settings_open = true
	_paused_before_settings = paused
	paused = true
	_refresh_speed_buttons()

func _check_settings_closed() -> void:
	if settings_open and not is_instance_valid(_settings_overlay):
		settings_open = false
		paused = _paused_before_settings
		_refresh_speed_buttons()

func set_speed(s: float) -> void:
	if s <= 0.0:
		paused = not paused
	else:
		speed = s
		paused = false
	_refresh_speed_buttons()

func _refresh_speed_buttons() -> void:
	for i in speed_buttons.size():
		var b: Button = speed_buttons[i]
		b.set_pressed_no_signal((i == 0 and paused) or (not paused and SPEEDS[i] == speed))

func _update_status() -> void:
	var n := [0, 0]
	for f in sim.fighters:
		if f.active():
			n[f.side] += 1
	var slow := "  SLOW" if _slowmo > 0.0 else ""
	status_label.text = "Tick %d   %s %d  vs  %s %d%s" % [sim.tick, side_names[0], n[0], side_names[1], n[1], slow]

# ------------------------------------------------------------------ playback
func _process(delta: float) -> void:
	_check_settings_closed()
	if not settings_open:
		_camera_keys(delta)
	_slowmo = maxf(0.0, _slowmo - delta)
	_slowmo_cd = maxf(0.0, _slowmo_cd - delta)
	if not sim.is_over() and not paused:
		var rate := TICKS_PER_SEC * speed * (SLOWMO_FACTOR if _slowmo > 0.0 else 1.0)
		_acc += delta * rate
		var guard := 0
		while _acc >= 1.0 and guard < 16 and not sim.is_over():
			_acc -= 1.0
			_do_tick()
			guard += 1
		if guard >= 16:
			_acc = 0.0
	var frac := clampf(_acc, 0.0, 1.0) if not sim.is_over() else 1.0
	for v in views:
		v.update_visual(frac, delta)
	arrows_layer.frac = frac
	_update_feed(delta)
	_update_camera(delta)
	if sim.is_over() and not result_shown:
		_over_timer += delta
		if _over_timer >= RESULT_DELAY:
			show_result()

## Advance one sim tick and present its events.
func _do_tick() -> void:
	sim.step()
	var touched := {}
	for e in sim.new_events:
		_present_event(e, touched)
	blood.tick(sim, views)
	if selected >= 0:
		inspector.refresh(touched.has(selected))
	_update_status()

## Test/debug: advance n ticks synchronously with full presentation.
func step_ticks(n: int) -> void:
	for i in n:
		if sim.is_over():
			return
		_do_tick()
		for v in views:
			v.update_visual(1.0, 1.0 / TICKS_PER_SEC)

func skip_to_end() -> void:
	if sim.is_over():
		return
	_skipping = true
	var guard := 0
	while not sim.is_over() and guard < 50000:
		_do_tick()
		guard += 1
	_skipping = false
	_slowmo = 0.0
	fx.clear_all()
	blood.clear_all()
	for v in views:
		v.settle()
	_over_timer = RESULT_DELAY
	_update_status()

func _view(i: int):
	return views[i] if i >= 0 and i < views.size() else null

func _present_event(e: Dictionary, touched: Dictionary) -> void:
	var type: String = e.get("type", "")
	var a: int = int(e.get("actor", -1))
	var t: int = int(e.get("target", -1))
	var def_i := t if t >= 0 else a
	touched[a] = true
	touched[t] = true
	if bool(e.get("decisive", false)):
		_add_feed(e)
		if not _skipping and _wants_slowmo(e):
			_trigger_slowmo(def_i)
	if type == "sever":
		_drop_piece(def_i, str(e.get("part", "")))
	if _skipping:
		return
	var av = _view(a)
	var dv = _view(def_i)
	if dv != null and (type == "hit" or type == "sever"):
		_spray(e, av, dv)
	if type in ["hit", "wound", "artery", "sever", "drop", "freed", "lodged", "death"]:
		if dv: dv.doll.refresh()   # wound overlay / missing part / gear in hand changed
		if av and av != dv: av.doll.refresh()
	# Routine floating text (dodge/block/hit location) only around the inspected unit, so a 50-a-side melee
	# stays readable; the log carries the detail. Decisive text (SEVERED, slain) always shows.
	var near_sel := selected >= 0 and (a == selected or t == selected)
	match type:
		"attack", "shoot":   # bows: the loose shows as the strike pose (the draw is the prepare pose)
			if av: av.flash("strike")
		"dodge":
			if dv:
				dv.flash("dodge")
				if near_sel: fx.add(dv.body_center() + Vector2(0, -26), "dodge", Color(0.85, 0.95, 1.0))
		"block", "parry":
			if dv:
				dv.flash("block")
				if near_sel: fx.add(dv.body_center() + Vector2(0, -26), type, Color(0.75, 0.85, 1.0))
		"hit", "wound", "artery":
			if dv:
				dv.flash("hit")
				var part := _part_name(dv.fighter, str(e.get("part", "")))
				if near_sel or type == "artery":
					fx.add(dv.body_center() + Vector2(0, -26), part if part != "" else "hit", Color(1.0, 0.7, 0.3) if type == "hit" else Color(1.0, 0.35, 0.3))
		"sever":
			if dv: dv.flash("hit"); fx.add(dv.body_center() + Vector2(0, -30), "SEVERED", Color(1.0, 0.25, 0.2), 18)
		"death":
			if dv: fx.add(dv.body_center() + Vector2(0, -30), "slain", Color(1.0, 0.3, 0.25), 17)
		"snap":   # v0.014: the attacker's weapon broke on the blow
			if av:
				av.doll.refresh()
				fx.add(av.body_center() + Vector2(0, -30), "SNAP!", Color(0.95, 0.85, 0.6), 17)
		"unconscious":
			if av: fx.add(av.body_center() + Vector2(0, -26), "out cold", Color(0.8, 0.7, 1.0))
		"learn":
			if av and av.fighter.side == 0: fx.add(av.body_center() + Vector2(0, -40), "+skill", Color(0.5, 1.0, 0.5))

## v0.014: blood droplets sized by the strike's REAL damage (the sum of its tissue layers' damage, the artery's rate);
## a sever throws a big burst. Nothing for a blow that drew no blood (no layers).
func _spray(e: Dictionary, av, dv) -> void:
	var n := 0
	if e["type"] == "sever":
		n = 30
	elif e.has("entry"):
		var D: Dictionary = e["entry"].get("d", {})
		var s := 0.0
		for l in D.get("layers", []):
			if String(l[1]) != "bone" or float(l[3]) > 0.3:   # a bruised or broken bone under intact skin does not bleed out
				s += float(l[3])
		n = clampi(int(s * 14.0 + float(D.get("art", 0.0)) * 150.0), 0, 40)
		if D.get("layers", []).is_empty():
			n = 0
	if n <= 0:
		return
	var dir := Vector2(1, 0)
	if av != null:
		dir = (dv.position - av.position)
	blood.spray(dv.body_center(), dir, n, dv.position.y)

## A severed part lies on the ground at the unit's tile: a static decal from Paperdoll.make_severed_piece.
## (Flying-off animation would sit behind Game.setting("anim_limb_flyoff"); not built.)
func _drop_piece(idx: int, pid: String) -> void:
	var v = _view(idx)
	if v == null or pid == "":
		return
	var piece: Node2D = Paperdoll.make_severed_piece(v.fighter.unit, pid)
	if piece == null:
		return
	var rng := RandomNumberGenerator.new()
	rng.seed = hash(str(sim.tick) + pid + str(idx))
	var dir := -1.0 if v.fighter.facing > 0 else 1.0   # lands behind the unit, away from the blow
	piece.position = v.cell_pos(v.fighter.cell) + Vector2(dir * rng.randf_range(8, 18), rng.randf_range(-8, 6))
	piece.rotation = rng.randf_range(-0.6, 0.6)
	if not Game.gore_full():   # v0.014 Gore: Reduced: the piece is smaller and dimmed
		piece.scale *= 0.6
		piece.modulate = Color(0.55, 0.5, 0.5, 0.8)
	gore_layer.add_child(piece)
	gore_pieces.append({"node": piece, "fighter": idx, "part": pid})

func _part_name(f, pid: String) -> String:
	if pid == "" or f == null:
		return ""
	var d: Dictionary = f.unit.body.part_def(pid)
	return str(d.get("name", pid))

func _wants_slowmo(e: Dictionary) -> bool:
	var type: String = e.get("type", "")
	var txt := BattleSim.event_text(e).to_lower()
	if type == "sever" or type == "artery":
		return true
	if type == "death" and (str(e.get("part", "")) == "head" or "head" in txt):
		return true
	return false

func _trigger_slowmo(idx: int) -> void:
	var v = _view(idx)
	if v == null or _slowmo_cd > 0.0 or paused:
		return
	_slowmo = SLOWMO_TIME
	_slowmo_cd = SLOWMO_COOLDOWN + SLOWMO_TIME
	v.highlight = SLOWMO_TIME
	# zoom-nudge only when the blow is on screen, so we never yank the camera across the map
	var view_rect := Rect2(cam_pos - _view_size() * 0.5, _view_size())
	if view_rect.has_point(v.body_center()):
		_nudge_target = v.body_center()
		_nudge_amount = 1.0

# ------------------------------------------------------------------ feed
func _add_feed(e: Dictionary) -> void:
	var b := Button.new()
	b.text = BattleSim.event_text(e)
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	b.custom_minimum_size = Vector2(500, 48)
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", 18)
	var a: int = int(e.get("actor", -1))
	var col := Color(1.0, 0.92, 0.6)
	if a >= 0 and a < sim.fighters.size():
		col = Color(0.65, 0.85, 1.0) if sim.fighters[a].side == 0 else Color(1.0, 0.6, 0.55)
	b.add_theme_color_override("font_color", col)
	b.add_theme_color_override("font_hover_color", col)
	b.add_theme_stylebox_override("normal", _box(Color(0, 0, 0, 0.6), 8))
	b.add_theme_stylebox_override("hover", _box(Color(0.1, 0.1, 0.1, 0.7), 8))
	b.add_theme_stylebox_override("pressed", _box(Color(0.2, 0.2, 0.2, 0.7), 8))
	b.set_meta("age", 0.0)
	var t: int = int(e.get("target", -1))
	var focus_i := t if t >= 0 else a
	b.pressed.connect(func():
		if focus_i >= 0:
			select(focus_i)
			center_on(focus_i))
	feed_box.add_child(b)
	while feed_box.get_child_count() > FEED_MAX:
		var old := feed_box.get_child(0)
		feed_box.remove_child(old)
		old.queue_free()

func _update_feed(delta: float) -> void:
	for c in feed_box.get_children():
		var age: float = c.get_meta("age", 0.0) + delta
		c.set_meta("age", age)
		c.modulate.a = clampf((FEED_LIFE - age) / 2.0, 0.0, 1.0)
		if age > FEED_LIFE:
			c.queue_free()

# ------------------------------------------------------------------ selection / inspector
func select(idx: int) -> void:
	if selected >= 0 and selected < views.size():
		views[selected].selected = false
	selected = idx
	if idx < 0:
		inspector.visible = false
		inspector.fighter = null
		return
	views[idx].selected = true
	inspector.show_fighter(sim.fighters[idx], sim)

## Public for tests/debug: a tap at a screen position.
func tap_screen(screen_pos: Vector2) -> void:
	var world := get_viewport().get_canvas_transform().affine_inverse() * screen_pos
	tap_world(world)

func tap_world(p: Vector2) -> void:
	var best := -1
	var bd := 34.0
	for v in views:
		if v.gone or not v.visible:
			continue
		var d: float = v.body_center().distance_to(p)
		if v.fighter.state == "dead":
			d += 8.0   # prefer the living when bodies overlap
		if d < bd:
			bd = d
			best = v.fighter.idx
	select(best)
	if best >= 0:
		_keep_visible(best)

func center_on(idx: int) -> void:
	var v = _view(idx)
	if v:
		cam_pos = v.body_center()
		if inspector.visible:   # centre in the part of the screen the panel leaves free
			cam_pos.x += Inspector.WIDTH * 0.5 / cam_zoom

## After a tap opens the inspector, pan just enough that the unit isn't hidden under the panel.
func _keep_visible(idx: int) -> void:
	var v = _view(idx)
	if v == null:
		return
	var sx: float = screen_pos_of(idx).x
	var free_w := get_viewport_rect().size.x - Inspector.WIDTH
	if sx > free_w - 60.0:
		cam_pos.x += (sx - free_w * 0.5) / cam_zoom

func screen_pos_of(idx: int) -> Vector2:
	return get_viewport().get_canvas_transform() * views[idx].body_center()

# ------------------------------------------------------------------ result
func show_result() -> void:
	if result_shown:
		return
	result_shown = true
	var w: int = sim.winner
	var dead := [0, 0]; var fled := [0, 0]; var down := [0, 0]
	for f in sim.fighters:
		match f.state:
			"dead": dead[f.side] += 1
			"fled": fled[f.side] += 1
			"unconscious", "prone": down[f.side] += 1
	result_panel = PanelContainer.new()
	result_panel.add_theme_stylebox_override("panel", _box(Color(0.08, 0.07, 0.06, 0.94), 24))
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	result_panel.add_child(v)
	var title := Label.new()
	title.text = "VICTORY" if w == 0 else ("DEFEAT" if w == 1 else "STALEMATE")
	title.add_theme_font_size_override("font_size", 56)
	title.add_theme_color_override("font_color", Color(1, 0.85, 0.3) if w == 0 else Color(1, 0.35, 0.3))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(title)
	var info := Label.new()
	info.text = "%s: %d dead, %d fled, %d down\n%s: %d dead, %d fled, %d down\n%d ticks" % [side_names[0], dead[0], fled[0], down[0], side_names[1], dead[1], fled[1], down[1], sim.tick]
	info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(info)
	var cont := _big_button("Continue", Vector2(280, 72))
	cont.add_theme_font_size_override("font_size", 26)
	cont.pressed.connect(finish)
	v.add_child(cont)
	ui.add_child(result_panel)
	result_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER, Control.PRESET_MODE_MINSIZE)

func build_result() -> Dictionary:
	var p := []; var en := []; var fallen := []; var all := []; var fled := []
	for f in sim.fighters:
		all.append(f.unit)
		if f.side == 0:
			p.append(f.unit)
		else:
			en.append(f.unit)
			if f.state == "dead" or f.state == "fled":
				fallen.append(f.unit)
			if f.state == "fled":
				fled.append(f.unit)
	if sim._bows_on:   # bows: lodged arrows pulled on the field; what lies on the field for whoever holds it
		Archery.pull_lodged(sim)
	return {"winner": sim.winner, "player_units": p, "enemy_units": en, "enemy_fallen": fallen, "enemy_fled": fled,
		"events": sim.events, "fighter_units": all, "ticks": sim.tick, "growth": sim.apply_battle_growth(),
		"arrow_field": sim.arrow_field.duplicate(true)}

func finish() -> void:
	if finished:
		return
	finished = true
	Game.finish_battle(build_result())

# ------------------------------------------------------------------ camera
func _view_size() -> Vector2:
	return get_viewport_rect().size / (cam_zoom * (1.0 + 0.18 * _nudge))

func _min_zoom() -> float:
	var vp := get_viewport_rect().size
	var ms := map_size() + Vector2(MAP_MARGIN, MAP_MARGIN) * 2.0
	return minf(maxf(vp.x / ms.x, vp.y / ms.y), 1.0)

func _fit_camera() -> void:
	cam_pos = map_size() * 0.5
	cam_zoom = _min_zoom() if sim.grid_w <= SMALL_GRID.x else maxf(_min_zoom(), 0.7)
	_update_camera(0.0)

func _camera_keys(delta: float) -> void:
	var d := Vector2(Input.get_axis("cam_left", "cam_right"), Input.get_axis("cam_up", "cam_down"))
	if d != Vector2.ZERO:
		cam_pos += d * 700.0 * delta / cam_zoom

func _update_camera(delta: float) -> void:
	if _nudge_amount > 0.0 and _slowmo <= 0.0:
		_nudge_amount = 0.0
	_nudge = move_toward(_nudge, _nudge_amount, delta * (4.0 if _nudge_amount > _nudge else 1.5))
	var z := cam_zoom * (1.0 + 0.18 * _nudge)
	var p := cam_pos.lerp(_nudge_target, 0.35 * _nudge)
	cam_pos = _clamp_pos(cam_pos, cam_zoom)
	p = _clamp_pos(p, z)
	camera.zoom = Vector2(z, z)
	camera.position = p

func _clamp_pos(p: Vector2, z: float) -> Vector2:
	var view := get_viewport_rect().size / z
	var r := Rect2(-Vector2(MAP_MARGIN, MAP_MARGIN), map_size() + Vector2(MAP_MARGIN, MAP_MARGIN) * 2.0)
	if inspector != null and inspector.visible:
		# the panel covers the right edge: let the camera pan far enough to show the map's right side beside it
		r.size.x += Inspector.WIDTH / z
	var o := p
	for ax in 2:
		if view[ax] >= r.size[ax]:
			o[ax] = r.position[ax] + r.size[ax] * 0.5
		else:
			o[ax] = clampf(p[ax], r.position[ax] + view[ax] * 0.5, r.end[ax] - view[ax] * 0.5)
	return o

func zoom_at(screen_pos: Vector2, factor: float) -> void:
	var before := get_viewport().get_canvas_transform().affine_inverse() * screen_pos
	cam_zoom = clampf(cam_zoom * factor, _min_zoom(), MAX_ZOOM)
	# keep the point under the finger fixed
	var vp := get_viewport_rect().size
	cam_pos = before - (screen_pos - vp * 0.5) / cam_zoom

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed:
				_pressing = true
				_dragging = false
				_press_pos = mb.position
			else:
				if _pressing and not _dragging:
					tap_screen(mb.position)
				_pressing = false
				_dragging = false
		elif mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_UP:
			zoom_at(mb.position, 1.12)
		elif mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			zoom_at(mb.position, 1.0 / 1.12)
	elif event is InputEventMouseMotion and _pressing:
		var mm := event as InputEventMouseMotion
		if not _dragging and mm.position.distance_to(_press_pos) > DRAG_THRESHOLD:
			_dragging = true
		if _dragging:
			cam_pos -= mm.relative / cam_zoom
	elif event is InputEventMagnifyGesture:
		var g := event as InputEventMagnifyGesture
		zoom_at(g.position, g.factor)
	elif event is InputEventPanGesture:
		cam_pos += (event as InputEventPanGesture).delta * 20.0 / cam_zoom
