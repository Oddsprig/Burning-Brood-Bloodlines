extends Control
## Settings screen ("settings"): one toggle per Game.SETTING_LABELS entry, saved with Game.set_setting.
## As a screen: Back -> Game.screen_params["back"] (default "title").
## As an overlay (e.g. over a battle): `var s = load("res://ui/settings.tscn").instantiate(); s.overlay = true;
## add_child(s)` -- Back then just frees it, and a dim backdrop covers the scene underneath.

var overlay := false
var list: VBoxContainer

func _ready() -> void:
	theme = UiTheme.get_theme()
	set_anchors_preset(PRESET_FULL_RECT)
	mouse_filter = MOUSE_FILTER_STOP
	if overlay:
		var dim := ColorRect.new()
		dim.color = Color(0.05, 0.03, 0.01, 0.75)
		dim.set_anchors_preset(PRESET_FULL_RECT)
		add_child(dim)
	else:
		var bg := WoodBg.new()
		bg.set_anchors_preset(PRESET_FULL_RECT)
		add_child(bg)
	var center := CenterContainer.new()
	center.set_anchors_preset(PRESET_FULL_RECT)
	add_child(center)
	var p := UiKit.panel()
	p.custom_minimum_size = Vector2(720, 0)
	center.add_child(p)
	var v := UiKit.vbox(10)
	p.add_child(v)
	var top := UiKit.hbox()
	var t := UiKit.label("Settings", "H2")
	t.add_theme_font_size_override("font_size", 32)
	top.add_child(t)
	top.add_child(UiKit.spacer())
	top.add_child(UiKit.button("Back", _back, "", 140))
	v.add_child(top)
	v.add_child(HSeparator.new())
	list = UiKit.vbox(8)
	v.add_child(list)
	_build()

func _build() -> void:
	UiKit.clear(list)
	# v0.014: settings with named choices (Gore: Full / Reduced); the button shows the current one and cycles
	var choices: Dictionary = Game.SETTING_CHOICES if "SETTING_CHOICES" in Game else {}
	for key in choices:
		var c: Dictionary = choices[key]
		var opts: Array = c["options"]
		var cur := String(Game.setting(key))
		var idx := 0
		for i in opts.size():
			if String(opts[i][0]) == cur:
				idx = i
		var row := UiKit.panel("Card")
		var cv := UiKit.vbox(4)
		row.add_child(cv)
		var h := UiKit.hbox(12)
		cv.add_child(h)
		var l := UiKit.label(String(c["label"]), "H2")
		l.add_theme_font_size_override("font_size", 22)
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		h.add_child(l)
		var nxt: String = String(opts[(idx + 1) % opts.size()][0])
		var b := UiKit.button(String(opts[idx][1]), func():
			Game.set_setting(key, nxt)
			_build(), "", 160)
		b.name = "Choice_" + key
		h.add_child(b)
		if c.has("hint"):
			var hl := UiKit.label(String(c["hint"]), "Muted")
			hl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			cv.add_child(hl)
		list.add_child(row)
	list.add_child(UiKit.label("Battle event animations (off by default)", "Muted"))
	var labels: Dictionary = Game.SETTING_LABELS if "SETTING_LABELS" in Game else {}
	if labels.is_empty():
		list.add_child(UiKit.label("No settings yet.", "Muted"))
	for key in labels:
		var on := bool(Game.setting(key))
		var row := UiKit.panel("Card")
		var h := UiKit.hbox(12)
		row.add_child(h)
		var l := UiKit.label(String(labels[key]), "H2")
		l.add_theme_font_size_override("font_size", 22)
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		h.add_child(l)
		var b := UiKit.button("ON" if on else "OFF", func():
			Game.set_setting(key, not bool(Game.setting(key)))
			_build(), "" if on else "Row", 120)
		h.add_child(b)
		list.add_child(row)

func _back() -> void:
	if overlay:
		queue_free()
		return
	Game.goto(String(Game.screen_params.get("back", "title")))
