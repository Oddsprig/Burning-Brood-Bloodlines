extends Control
## Aftermath screen: reads Game.last_result (filled by Game.finish_battle).
## Victory/defeat, loot gold, the fallen (officers highlighted - officer death is permadeath),
## the wounded with their status, skill-ups ("learn" events), Continue -> world map.

const GOLD := Color(1.0, 0.82, 0.3)
const RED := Color(1.0, 0.4, 0.35)

func _ready() -> void:
	var th := Theme.new()
	th.default_font_size = 20
	theme = th
	var bg := ColorRect.new()
	bg.color = Color(0.11, 0.09, 0.08)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var r: Dictionary = Game.last_result
	var root := VBoxContainer.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.offset_left = 24; root.offset_right = -24; root.offset_top = 16; root.offset_bottom = -16
	root.add_theme_constant_override("separation", 10)
	add_child(root)
	var w := int(r.get("winner", -1))
	var title := Label.new()
	title.text = "VICTORY" if w == 0 else ("DEFEAT" if w == 1 else "THE FIELD IS LEFT UNDECIDED")
	title.add_theme_font_size_override("font_size", 52)
	title.add_theme_color_override("font_color", GOLD if w == 0 else RED)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	root.add_child(title)
	var enemy_fallen: Array = r.get("enemy_fallen", [])
	var enemy_all: Array = r.get("enemy_units", [])
	var slain := enemy_fallen.filter(func(u): return u.dead).size()
	var sub := Label.new()
	var coin := int(r.get("loot_coin", 0))
	sub.text = "Loot: %d coins (%d coin on the bodies, the rest scrap and gear sold)    Enemies slain: %d   fled: %d   of %d    Treasury: %d coins" % [int(r.get("loot_gold", 0)), coin, slain, enemy_fallen.size() - slain, enemy_all.size(), Game.gold]
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.add_theme_color_override("font_color", Color(0.95, 0.9, 0.75))
	root.add_child(sub)
	var kept: Array = r.get("loot_items", [])
	if not kept.is_empty() or int(r.get("fallen_gear", 0)) > 0:
		var kl := Label.new()
		var parts := []
		if not kept.is_empty():
			parts.append("Kept for the stash:")
		if int(r.get("fallen_gear", 0)) > 0:
			parts.append("Gear of our fallen brought back: %d pieces" % int(r["fallen_gear"]))
		kl.text = "    ".join(parts)
		kl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		kl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		kl.add_theme_color_override("font_color", Color(0.85, 0.95, 0.75))
		root.add_child(kl)
		if not kept.is_empty():   # each kept piece with its icon (art/item_icon.gd), name and wear
			var fl := HFlowContainer.new()
			fl.name = "LootItems"
			fl.alignment = FlowContainer.ALIGNMENT_CENTER
			fl.add_theme_constant_override("h_separation", 14)
			root.add_child(fl)
			for i in kept:
				var one := HBoxContainer.new()
				one.add_theme_constant_override("separation", 4)
				one.add_child(UiKit.icon(ItemIcon.for_item(i), 36))
				var il := Label.new()
				il.text = "%s (%s)" % [i.display_name(), Baggage.WEAR_WORDS[clampi(i.wear, 0, 3)]]
				il.add_theme_color_override("font_color", Color(0.85, 0.95, 0.75))
				il.add_theme_font_size_override("font_size", 17)
				il.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
				one.add_child(il)
				fl.add_child(one)
	# monsters wave 1: creature trophies auto-sold, a cleared camp's hoard, the town's bonus for sparing its militia
	var extra := []
	var tro: Array = r.get("trophies", [])
	if not tro.is_empty():
		extra.append("Trophies sold for %d coins: %s" % [int(r.get("trophy_gold", 0)), ", ".join(tro.map(func(x): return "%s (%d)" % [x["name"], int(x["gold"])]).slice(0, 6))])
	if not (r.get("supplies_taken", {}) as Dictionary).is_empty():   # economy spec 2: the beaten force's stores
		extra.append("Supplies taken: " + Supplies.text(r["supplies_taken"]))
	if int(r.get("camp_loot", 0)) > 0:
		extra.append("The camp's hoard sold for %d coins" % int(r["camp_loot"]))
	if int(r.get("militia_bonus", 0)) > 0:
		extra.append("Bonus for sparing the militia: %d coins" % int(r["militia_bonus"]))
	if not extra.is_empty():
		var ex := Label.new()
		ex.text = "    ".join(extra)
		ex.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		ex.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		ex.add_theme_color_override("font_color", GOLD)
		root.add_child(ex)
	var cols := HBoxContainer.new()
	cols.size_flags_vertical = Control.SIZE_EXPAND_FILL
	cols.add_theme_constant_override("separation", 14)
	root.add_child(cols)
	var players: Array = r.get("player_units", [])
	# Fallen
	var fallen_box := _column(cols, "The Fallen")
	var fallen := players.filter(func(u): return u.dead)
	if fallen.is_empty():
		_line(fallen_box, "No one. The company stands whole.", Color(0.6, 0.9, 0.6))
	for u in fallen:
		if u.is_officer():
			_line(fallen_box, "%s, %s - %s. Gone forever." % [u.name, u.role, u.title], GOLD, 21)
		else:
			_line(fallen_box, "%s, %s" % [u.name, u.title], Color(0.9, 0.85, 0.8))
	# Wounded
	var wounded_box := _column(cols, "Wounded")
	var any_w := false
	for u in players:
		if u.dead or not u.body.is_wounded():
			continue
		any_w = true
		var rep: Dictionary = HealthReport.describe(u)
		var hd := float(rep.get("heal_days", 0.0))
		var s := "%s - %s" % [u.name, str(rep.get("status", "wounded"))]
		if hd > 0.0:
			s += ", ~%d days" % int(ceil(hd))
		var col := GOLD if u.is_officer() else Color(1.0, 0.75, 0.45)
		_line(wounded_box, s, col)
		var summ: Array = rep.get("summary", [])
		if not summ.is_empty():
			_line(wounded_box, "    " + ", ".join(summ.slice(0, 3).map(func(x): return str(x))), Color(0.75, 0.72, 0.68), 16)
	if not any_w:
		_line(wounded_box, "No wounds of note.", Color(0.6, 0.9, 0.6))
	# Skill-ups
	var learn_box := _column(cols, "Lessons Learned")
	var fu: Array = r.get("fighter_units", [])
	var any_l := false
	for e in r.get("events", []):
		if e.get("type", "") != "learn":
			continue
		var a := int(e.get("actor", -1))
		if a >= 0 and a < fu.size() and not players.has(fu[a]):
			continue   # enemy learning is not our news
		any_l = true
		_line(learn_box, BattleSim.event_text(e), Color(0.6, 1.0, 0.6))
	var growth: Dictionary = r.get("growth", {})
	for idx in growth:
		var gi := int(idx)
		if gi < 0 or gi >= fu.size() or not players.has(fu[gi]) or fu[gi].dead:
			continue
		var bits := []
		for a in growth[idx]:
			bits.append("%s +%d" % [a, int(growth[idx][a])])
		any_l = true
		_line(learn_box, "%s grows: %s" % [fu[gi].name, ", ".join(bits)], Color(0.55, 0.85, 1.0))
	if not any_l:
		_line(learn_box, "Nothing new was learned.", Color(0.7, 0.7, 0.7))
	var cont := Button.new()
	cont.text = "Continue"
	cont.custom_minimum_size = Vector2(300, 72)
	cont.add_theme_font_size_override("font_size", 26)
	cont.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	cont.pressed.connect(func(): Game.goto("map"))
	root.add_child(cont)

func _column(parent: Control, title: String) -> VBoxContainer:
	var p := PanelContainer.new()
	p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.17, 0.14, 0.12)
	sb.set_corner_radius_all(8)
	sb.set_content_margin_all(12)
	p.add_theme_stylebox_override("panel", sb)
	parent.add_child(p)
	var v := VBoxContainer.new()
	p.add_child(v)
	var h := Label.new()
	h.text = title
	h.add_theme_font_size_override("font_size", 26)
	h.add_theme_color_override("font_color", Color(0.95, 0.75, 0.4))
	v.add_child(h)
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	v.add_child(sc)
	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(list)
	return list

func _line(box: VBoxContainer, text: String, col: Color, size := 18) -> void:
	var l := Label.new()
	l.text = text
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	box.add_child(l)
