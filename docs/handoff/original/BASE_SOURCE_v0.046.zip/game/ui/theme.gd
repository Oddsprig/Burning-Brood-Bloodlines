class_name UiTheme
extends RefCounted
## Shared menu theme, built in code: dark wood frame, parchment panels, copper buttons.
## Large type and >= 48 px controls for phones. Type variations:
##   Label: "Header" (light, bold, on wood), "Title", "H2" (bold ink on parchment), "Muted", "Good", "Bad", "Small"
##   Button: "Row" (parchment list row), "RowOn" (selected row), "Danger", "Tab", "TabOn"
##   PanelContainer: "Card" (lighter parchment), "Bar" (wood strip), "Inset" (sunken parchment)

const WOOD := Color("2b1c12")
const WOOD_2 := Color("47301f")
const WOOD_3 := Color("5e4029")
const PARCH := Color("f1e4c3")
const PARCH_2 := Color("e4d2a3")
const PARCH_3 := Color("d6bf88")
const INK := Color("2a1a0c")
const INK_SOFT := Color("6e5236")
const LIGHT := Color("fff4dc")
const COPPER := Color("c0622a")
const COPPER_HI := Color("dd7d3c")
const COPPER_LO := Color("8a4216")
const BRASS := Color("f0c24f")
const BORDER := Color("4f3218")
const GOOD := Color("2e7a2e")
const BAD := Color("b02a1e")
const WARN := Color("b86e00")
const BLUE := Color("2f5d8a")

const FONT_SIZE := 20

static var _theme: Theme
static var _bold: Font

static func get_theme() -> Theme:
	if _theme == null:
		_theme = _build()
	return _theme

static func bold() -> Font:
	if _bold == null:
		var f := FontVariation.new()
		f.base_font = ThemeDB.fallback_font
		f.variation_embolden = 0.7
		_bold = f
	return _bold

static func sb(bg: Color, border: Color = BORDER, bw: int = 2, radius: int = 6, mx: int = 12, my: int = 8) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(bw)
	s.set_corner_radius_all(radius)
	s.content_margin_left = mx
	s.content_margin_right = mx
	s.content_margin_top = my
	s.content_margin_bottom = my
	s.anti_aliasing = true
	return s

static func _btn(t: Theme, type: String, bg: Color, fg: Color, border: Color = BORDER) -> void:
	t.set_stylebox("normal", type, sb(bg, border))
	t.set_stylebox("hover", type, sb(bg.lightened(0.12), border))
	t.set_stylebox("pressed", type, sb(bg.darkened(0.18), border))
	t.set_stylebox("hover_pressed", type, sb(bg.darkened(0.12), border))
	t.set_stylebox("disabled", type, sb(bg.lerp(Color("9a8b74"), 0.65), border.lerp(Color("9a8b74"), 0.5)))
	var f := StyleBoxFlat.new()
	f.draw_center = false
	f.border_color = BRASS
	f.set_border_width_all(2)
	f.set_corner_radius_all(6)
	t.set_stylebox("focus", type, f)
	for c in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color", "font_hover_pressed_color"]:
		t.set_color(c, type, fg)
	t.set_color("font_disabled_color", type, fg.lerp(Color("6e6150"), 0.6))
	t.set_font_size("font_size", type, FONT_SIZE)

static func _build() -> Theme:
	var t := Theme.new()
	t.default_font_size = FONT_SIZE
	# Labels
	t.set_color("font_color", "Label", INK)
	t.set_font_size("font_size", "Label", FONT_SIZE)
	_variation(t, "Header", "Label")
	t.set_color("font_color", "Header", LIGHT)
	t.set_font("font", "Header", bold())
	t.set_font_size("font_size", "Header", 28)
	t.set_color("font_shadow_color", "Header", Color(0, 0, 0, 0.55))
	t.set_constant("shadow_offset_x", "Header", 2)
	t.set_constant("shadow_offset_y", "Header", 2)
	_variation(t, "Title", "Label")
	t.set_color("font_color", "Title", BRASS)
	t.set_font("font", "Title", bold())
	t.set_font_size("font_size", "Title", 84)
	t.set_color("font_outline_color", "Title", Color("3a1a08"))
	t.set_constant("outline_size", "Title", 14)
	t.set_color("font_shadow_color", "Title", Color(0, 0, 0, 0.6))
	t.set_constant("shadow_offset_x", "Title", 4)
	t.set_constant("shadow_offset_y", "Title", 5)
	_variation(t, "H2", "Label")
	t.set_font("font", "H2", bold())
	t.set_font_size("font_size", "H2", 24)
	t.set_color("font_color", "H2", INK)
	_variation(t, "Muted", "Label")
	t.set_color("font_color", "Muted", INK_SOFT)
	t.set_font_size("font_size", "Muted", 18)
	_variation(t, "Small", "Label")
	t.set_color("font_color", "Small", INK)
	t.set_font_size("font_size", "Small", 17)
	_variation(t, "Good", "Label")
	t.set_color("font_color", "Good", GOOD)
	_variation(t, "Bad", "Label")
	t.set_color("font_color", "Bad", BAD)
	# Buttons
	_btn(t, "Button", COPPER, LIGHT)
	t.set_font("font", "Button", bold())
	_variation(t, "Row", "Button")
	_btn(t, "Row", PARCH_2, INK, PARCH_3.darkened(0.2))
	t.set_font("font", "Row", ThemeDB.fallback_font)
	_variation(t, "RowOn", "Button")
	_btn(t, "RowOn", Color("f6d77e"), INK, COPPER_LO)
	t.set_stylebox("normal", "RowOn", sb(Color("f6d77e"), COPPER_LO, 3))
	t.set_font("font", "RowOn", ThemeDB.fallback_font)
	_variation(t, "Danger", "Button")
	_btn(t, "Danger", BAD, LIGHT)
	_variation(t, "Tab", "Button")
	_btn(t, "Tab", WOOD_3, PARCH, Color("2a1a0c"))
	t.set_font_size("font_size", "Tab", 22)
	_variation(t, "TabOn", "Button")
	_btn(t, "TabOn", PARCH, INK, Color("2a1a0c"))
	t.set_font_size("font_size", "TabOn", 22)
	t.set_font("font", "TabOn", bold())
	t.set_constant("h_separation", "Button", 8)
	# OptionButton / MenuButton follow Button
	_btn(t, "OptionButton", PARCH_2, INK, BORDER)
	t.set_constant("arrow_margin", "OptionButton", 10)
	# Popup menus: parchment, tall rows for fingers
	t.set_stylebox("panel", "PopupMenu", sb(PARCH, BORDER, 3, 6, 6, 6))
	t.set_stylebox("hover", "PopupMenu", sb(Color("f6d77e"), COPPER_LO, 0, 4, 6, 6))
	t.set_color("font_color", "PopupMenu", INK)
	t.set_color("font_hover_color", "PopupMenu", INK)
	t.set_color("font_disabled_color", "PopupMenu", INK_SOFT)
	t.set_font_size("font_size", "PopupMenu", 22)
	t.set_constant("v_separation", "PopupMenu", 22)
	t.set_constant("item_start_padding", "PopupMenu", 14)
	# Panels
	t.set_stylebox("panel", "PanelContainer", sb(PARCH, BORDER, 3, 8, 14, 12))
	t.set_stylebox("panel", "Panel", sb(PARCH, BORDER, 3, 8))
	_variation(t, "Card", "PanelContainer")
	t.set_stylebox("panel", "Card", sb(Color("f8efd8"), PARCH_3.darkened(0.25), 2, 8, 12, 10))
	_variation(t, "Inset", "PanelContainer")
	t.set_stylebox("panel", "Inset", sb(PARCH_2, PARCH_3.darkened(0.15), 2, 6, 10, 8))
	_variation(t, "Bar", "PanelContainer")
	t.set_stylebox("panel", "Bar", sb(WOOD_2, Color("1a0f08"), 0, 0, 16, 8))
	# Scrollbars: thick for thumbs
	for sbt in ["VScrollBar", "HScrollBar"]:
		t.set_stylebox("scroll", sbt, sb(Color(0, 0, 0, 0.12), Color(0, 0, 0, 0), 0, 6, 7, 7))
		t.set_stylebox("grabber", sbt, sb(COPPER, COPPER_LO, 1, 6, 7, 7))
		t.set_stylebox("grabber_highlight", sbt, sb(COPPER_HI, COPPER_LO, 1, 6, 7, 7))
		t.set_stylebox("grabber_pressed", sbt, sb(COPPER_LO, COPPER_LO, 1, 6, 7, 7))
	t.set_stylebox("panel", "ScrollContainer", StyleBoxEmpty.new())
	# Progress bars (skill XP)
	t.set_stylebox("background", "ProgressBar", sb(PARCH_3, BORDER, 1, 4, 0, 0))
	t.set_stylebox("fill", "ProgressBar", sb(COPPER, COPPER_LO, 1, 4, 0, 0))
	t.set_color("font_color", "ProgressBar", INK)
	t.set_font_size("font_size", "ProgressBar", 14)
	# Rich text
	t.set_color("default_color", "RichTextLabel", INK)
	t.set_font_size("normal_font_size", "RichTextLabel", FONT_SIZE)
	t.set_font_size("bold_font_size", "RichTextLabel", FONT_SIZE)
	t.set_font("bold_font", "RichTextLabel", bold())
	# Separators
	var line := StyleBoxLine.new()
	line.color = PARCH_3.darkened(0.2)
	line.thickness = 2
	t.set_stylebox("separator", "HSeparator", line)
	t.set_constant("separation", "HSeparator", 10)
	t.set_constant("separation", "VBoxContainer", 8)
	t.set_constant("separation", "HBoxContainer", 8)
	return t

static func _variation(t: Theme, name: String, base: String) -> void:
	t.set_type_variation(name, base)
