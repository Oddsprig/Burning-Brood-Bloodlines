extends Node2D
## v0.014 battle gore (Douglas 22:51: "more gore-heavy when people are injured"), drawn from the REAL sim results:
##   spray(pos, dir, n)   blood droplets on a hit, n from the strike's real layer damage and artery (battle.gd)
##   tick(sim, views)     once per sim tick: trail drips behind bleeding fighters (their real Fighter.bleeding rate),
##                        arterial spurts from parts bleeding at artery rates, and a pool under every fighter who is
##                        down or dead that grows with the blood he has really lost (body.blood / blood_max).
## Cheap by construction: droplets live in a fixed pool of MAX_DROPS slots (packed arrays, no per-frame allocation);
## ground decals (drips, splats) are a ring buffer of MAX_DECALS that overwrites the oldest; pools are one per
## fighter. The decal node redraws only when something changed; the droplet node only while droplets fly.
## Gore Reduced (Game "gore"): a third of the droplets, no spurts, half-size pools, sparse trails.

const MAX_DROPS := 384
const MAX_DECALS := 900
const DROP_LIFE := 0.55
const GRAVITY := 520.0
const TRAIL_PER_RATE := 40.0      # drips per tick per unit of bleed rate (0.02/tick muscle cut -> a drip every ~1.2 ticks)
const SPURT_RATE := 0.03          # a part bleeding at least this much a tick spurts (Formulas.BLEED_WORDS[0]: an artery)
const SPURT_EVERY := 14           # ticks between spurts (a pulse)
const POOL_MAX := 30.0            # px radius at 45% blood lost (dead)
const BLOOD := Color("#b0101a")
const BLOOD_DARK := Color("#5e080e")

var full := true
var tile := 40.0

# droplets in flight
var _dp := PackedVector2Array()
var _dv := PackedVector2Array()
var _dl := PackedFloat32Array()   # life left (<= 0 = free slot)
var _dground := PackedFloat32Array()   # y where the drop lands
var _ds := PackedFloat32Array()   # size
var _alive := 0
var _next := 0

# ground decals (ring buffer)
var _gp := PackedVector2Array()
var _gr := PackedFloat32Array()
var _gc := PackedColorArray()
var _gn := 0
var _gi := 0
var _pools := {}                  # fighter idx -> [Vector2 centre, float radius]
var _trail_acc := {}              # fighter idx -> drip accumulator
var _rng := RandomNumberGenerator.new()

var decals: Node2D
var drops: Node2D

func setup(tile_px: float, gore_full: bool, rseed: int) -> void:
	tile = tile_px
	full = gore_full
	_rng.seed = rseed * 31 + 7
	_dp.resize(MAX_DROPS); _dv.resize(MAX_DROPS); _dl.resize(MAX_DROPS); _dground.resize(MAX_DROPS); _ds.resize(MAX_DROPS)
	_dl.fill(0.0)
	_gp.resize(MAX_DECALS); _gr.resize(MAX_DECALS); _gc.resize(MAX_DECALS)
	decals = Node2D.new()
	decals.draw.connect(_draw_decals)
	add_child(decals)
	drops = Node2D.new()
	drops.z_index = 6
	drops.draw.connect(_draw_drops)
	add_child(drops)

## Counts for tests and the perf check.
func decal_count() -> int:
	return _gn
func drop_count() -> int:
	return _alive
func pool_count() -> int:
	return _pools.size()
func pool_radius(idx: int) -> float:
	return float(_pools[idx][1]) if _pools.has(idx) else 0.0

## Blood droplets from `pos` (a body centre) flying along `dir` (attacker -> defender), n of them.
func spray(pos: Vector2, dir: Vector2, n: int, ground_y: float) -> void:
	if not full:
		n = n / 3
	if n <= 0:
		return
	var base := dir.normalized() if dir != Vector2.ZERO else Vector2.RIGHT
	for i in n:
		var s := _next
		_next = (_next + 1) % MAX_DROPS
		if _dl[s] <= 0.0:
			_alive += 1
		var a := base.rotated(_rng.randf_range(-0.9, 0.9))
		var sp := _rng.randf_range(60.0, 210.0)
		_dp[s] = pos + Vector2(_rng.randf_range(-3, 3), _rng.randf_range(-4, 4))
		_dv[s] = a * sp + Vector2(0, -_rng.randf_range(40.0, 140.0))
		_dl[s] = DROP_LIFE * _rng.randf_range(0.6, 1.0)
		_dground[s] = ground_y + _rng.randf_range(-6, 6)
		_ds[s] = _rng.randf_range(1.2, 2.6)
	set_process(true)

func _decal(p: Vector2, r: float, c: Color) -> void:
	_gp[_gi] = p
	_gr[_gi] = r
	_gc[_gi] = c
	_gi = (_gi + 1) % MAX_DECALS
	_gn = mini(_gn + 1, MAX_DECALS)

## One sim tick: drips, spurts, pools (all from the fighters' real bleeding and blood).
func tick(sim, views: Array) -> void:
	var changed := false
	for f in sim.fighters:
		if f.waiting or f.state == "fled":
			continue
		var v = views[f.idx]
		var rate := 0.0
		for pid in f.bleeding:
			rate += float(f.bleeding[pid])
		var down: bool = f.state == "dead" or f.state == "unconscious" or f.prone
		var feet: Vector2 = v.position
		if rate > 0.0 and f.state != "dead":
			var acc := float(_trail_acc.get(f.idx, 0.0)) + rate * TRAIL_PER_RATE * (1.0 if full else 0.35)
			while acc >= 1.0:
				acc -= 1.0
				_decal(feet + Vector2(_rng.randf_range(-9, 9), _rng.randf_range(-4, 3)), _rng.randf_range(1.0, 2.2) + minf(2.0, rate * 20.0),
					BLOOD if _rng.randf() < 0.6 else BLOOD_DARK)
				changed = true
			_trail_acc[f.idx] = acc
			if full and (sim.tick + f.idx) % SPURT_EVERY == 0:
				for pid in f.bleeding:
					if float(f.bleeding[pid]) >= SPURT_RATE:
						spray(v.body_center() + _part_offset(String(pid)), Vector2(float(f.facing) * -1.0, -0.6), 5 + int(float(f.bleeding[pid]) * 40.0), feet.y)
						break
		if down:
			var lost: float = 1.0 - clampf(f.unit.body.blood / maxf(f.unit.body.blood_max, 0.001), 0.0, 1.0)
			var r: float = (6.0 + POOL_MAX * sqrt(clampf(lost / 0.45, 0.0, 1.0))) * (1.0 if full else 0.5)
			var cur = _pools.get(f.idx)
			if cur == null:
				_pools[f.idx] = [feet + Vector2(0, -3), r]
				changed = true
			elif r > float(cur[1]) + 0.25:
				cur[1] = r   # pools only grow
				changed = true
	if changed:
		decals.queue_redraw()

## Rough height of a part on the figure (spurts come from the right place).
func _part_offset(pid: String) -> Vector2:
	if pid in ["head", "neck", "throat"] or pid.begins_with("ear") or pid.begins_with("eye"):
		return Vector2(0, -16)
	if pid.begins_with("leg") or pid.begins_with("foot") or pid.begins_with("toe"):
		return Vector2(0, 14)
	if pid.begins_with("arm") or pid.begins_with("hand") or pid.begins_with("finger"):
		return Vector2(8, 0)
	return Vector2.ZERO

func _process(delta: float) -> void:
	if _alive <= 0:
		set_process(false)
		return
	var landed := false
	for s in MAX_DROPS:
		if _dl[s] <= 0.0:
			continue
		_dl[s] -= delta
		_dv[s] = _dv[s] + Vector2(0, GRAVITY * delta)
		_dp[s] = _dp[s] + _dv[s] * delta
		if _dl[s] <= 0.0 or (_dv[s].y > 0.0 and _dp[s].y >= _dground[s]):
			_dl[s] = 0.0
			_alive -= 1
			if s % 2 == 0:   # every other droplet leaves a splat where it lands
				_decal(Vector2(_dp[s].x, minf(_dp[s].y, _dground[s])), _ds[s] * 1.3, BLOOD)
				landed = true
	drops.queue_redraw()
	if landed:
		decals.queue_redraw()

func _draw_decals() -> void:
	for idx in _pools:
		var pl: Array = _pools[idx]
		var c: Vector2 = pl[0]
		var r: float = pl[1]
		decals.draw_set_transform(c, 0.0, Vector2(1.0, 0.45))
		decals.draw_circle(Vector2.ZERO, r, BLOOD_DARK.lerp(BLOOD, 0.3))
		decals.draw_circle(Vector2(-r * 0.2, -r * 0.15), r * 0.55, BLOOD.darkened(0.1))
	decals.draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.6))
	for i in _gn:
		var p := _gp[i]
		decals.draw_circle(Vector2(p.x, p.y / 0.6), _gr[i], _gc[i])
	decals.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

func _draw_drops() -> void:
	for s in MAX_DROPS:
		if _dl[s] > 0.0:
			drops.draw_circle(_dp[s], _ds[s], BLOOD)

func clear_all() -> void:
	_dl.fill(0.0)
	_alive = 0
	drops.queue_redraw()
