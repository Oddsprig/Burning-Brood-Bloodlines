class_name TownDefence
extends RefCounted

static func eligible(town: Dictionary) -> int:
	if not TownEcon.has_econ(town): return 0
	var n := 0
	for f in town["econ"]["fams"]:
		if f.get("gone", false) or f.get("estate", false): continue
		n += maxi(0, Families.adults(f) - 1 - Families.serving(f) - f.get("keeps", []).size())
	return n

static func militia_target(town: Dictionary) -> int:
	if not TownEcon.has_econ(town): return 0
	var e: Dictionary = town["econ"]
	# The reserve is a town's available civilians, with drill pay backed by the actual treasury.
	var existing := 0
	for f in e["fams"]:
		for p in Persons.pp(f):
			if String(p[4]) in ["reserve", "militia"]: existing += 1
	var budget := int(maxf(0, float(e["treasury"])) / maxf(1, Army.wage("militia", 0)) / 7)
	return mini(eligible(town) + existing, budget)

static func guard_band(game, tid: String) -> Dictionary:
	return game.world["warbands"].get(String(game.world.get("town_guards", {}).get(tid, "")), {})

static func guards(game, tid: String) -> Array:
	return guard_band(game, tid).get("units", [])

static func garrison(game, tid: String) -> Array:
	return Militia.units_of(game, tid) + guards(game, tid)

static func set_muster(game, town: Dictionary, active: bool, drill: bool = false) -> void:
	var wb := Militia.band_of(game, String(town["id"]))
	if wb.is_empty(): return
	wb["mustered"] = active
	wb["drill_today"] = drill
	var e: Dictionary = town["econ"]
	var families: Array = e.get("fams", []) if TownEcon.has_econ(town) else []
	var wanted := "militia" if active or drill else "reserve"
	var affected := []
	for u in wb["units"]:
		# Complete the actual service transitions before households choose their
		# civilian work. Several units can belong to the same household.
		if u.family < 0 or u.family >= families.size(): continue
		var f: Dictionary = families[u.family]
		if f.is_empty(): continue
		var p := Persons.by_uid(f, u.uid)
		if p.is_empty(): continue
		var old := String(p[4])
		if old == wanted: continue
		if old == "militia": f["serve"]["militia"] = maxi(0, int(f["serve"].get("militia", 0)) - 1)
		if active or drill: f["serve"]["militia"] = int(f["serve"].get("militia", 0)) + 1
		p[4] = wanted
		if not affected.has(int(u.family)): affected.append(int(u.family))
	for fid in affected:
		Families.reassign(e, families[int(fid)])
	if not affected.is_empty():
		# Departing hands can release funded places after an idle household's
		# weekly turn. Match those civilians after every affected household has
		# released its places, using the ordinary funding and wage-claim rules.
		Families.match_idle(e)
	if not active:
		wb["path"] = []; wb["pos"] = town["pos"]

static func daily(game, town: Dictionary) -> void:
	var e: Dictionary = town["econ"]
	var tid := String(town["id"])
	var w: Dictionary = game.world
	if not w.has("town_guards"): w["town_guards"] = {}
	var P: Dictionary = e.get("plots", {})
	var posts := 0
	for i in Plots.count(P):
		if int(P["use"][i]) == Plots.ROAD and int(P["sub"][i]) == 1: posts += 1
	var affordable := int(maxf(0, float(e["treasury"])) / maxf(1, Army.wage("guard", 0)) / 14)
	var target := mini(posts * 3, affordable) # three eight-hour watches at each actual gate
	var gb := guard_band(game, tid)
	if gb.is_empty() and target > 0:
		var rng := RandomNumberGenerator.new(); rng.seed = hash([w.get("seed", 0), tid, "guards"])
		var units := []
		for i in mini(target, eligible(town)):
			var fid := People.draw(town, rng, "guard")
			if fid < 0: break
			var u := Factory.make_troop(rng, String(town["faction"]), Factory.pick_troop(rng, String(town["faction"])), int(town["wealth"]))
			People.bind(town, fid, u, "guard")
			u.home_town = tid; u.title = "town guard"
			TownEcon.outfit_units(town, [u], 1)
			units.append(u)
			Army.state(w)["roll"][str(u.uid)] = [tid, fid, "guard", u.name]
		if not units.is_empty():
			var wid := CampaignWorld.spawn_warband(game, String(town["faction"]), town["pos"], units.size(), "militia", rng,
				{"units": units, "home": tid, "anchor": town["pos"], "professional": true, "marching": false})
			w["town_guards"][tid] = wid
			gb = guard_band(game, tid)
	if not gb.is_empty():
		var living: Array = gb["units"].filter(func(u): return not u.dead)
		var paid := Army.pay_units(game, living, {"kind": "town", "e": e}, "guard", TownEcon.culture_of(e))
		e["stats"]["guard_wages"] = paid["paid"]
		var leaving := []
		for u in living:
			if u.unpaid_days >= int(Army.A()["desert_days"]): leaving.append(u)
		for u in leaving:
			Army.release(game, u, "deserted", "the town guard")
			gb["units"].erase(u)
		gb["units"] = gb["units"].filter(func(u): return not u.dead)
		# A patrol visits the real pasture plots, returning to the gate between rounds.
		if not gb.get("marching", false) and not gb["units"].is_empty():
			var pastures := []
			for i in Plots.count(P):
				if int(P["use"][i]) == Plots.PASTURE: pastures.append(i)
			if not pastures.is_empty():
				var index := posmod(int(game.day), pastures.size())
				gb["patrol_goal"] = HerdRaids.plot_pos(town, P, int(pastures[index]))
				gb["path"] = CampaignWorld.find_path(w, gb["pos"], gb["patrol_goal"])
				gb["marching"] = not gb["path"].is_empty()
	var mil := Militia.band_of(game, tid)
	if not mil.is_empty():
		var drill := posmod(int(game.day), 7) == posmod(int(town.get("size", 0)), 7)
		set_muster(game, town, bool(mil.get("mustered", false)), drill)
		if drill: mil["drill_days"] = int(mil.get("drill_days", 0)) + 1
	e["barracks_beds"] = maxi(garrison(game, tid).size(), militia_target(town) + target)

static func guard_step(game, wb: Dictionary, dt: float) -> void:
	if not wb.get("marching", false): return
	if CampaignWorld._step_along(game.world, wb, CampaignWorld.WARBAND_SPEED * dt):
		if (wb["pos"] as Vector2).distance_to(wb["anchor"]) > 1:
			wb["path"] = CampaignWorld.find_path(game.world, wb["pos"], wb["anchor"])
		else: wb["marching"] = false
