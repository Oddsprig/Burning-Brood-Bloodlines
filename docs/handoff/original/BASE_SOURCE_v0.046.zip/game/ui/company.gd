extends Control
## Company screen: roster as squads (left), unit sheet with tabs (right), squad uniform editor,
## move / promote / dismiss. Back returns to Game.screen_params["back"] (default: town if inside one, else map).

var selected_uid: int = -1
var tab: String = "Overview"
var list_box: VBoxContainer
var page: VBoxContainer
var tabs_box: HBoxContainer
var actions: HBoxContainer
var bar: HBoxContainer
var purse: Label
var provisions: VBoxContainer
const BAGGAGE := "res://ui/baggage.tscn"

func _ready() -> void:
	var f := UiKit.screen_frame(self, "The Company")
	bar = f["bar"]
	bar.add_child(UiKit.spacer())
	purse = UiKit.purse(Game)   # its own row under the bar: the whole sum always shows (a million coins and more)
	f["root"].add_child(purse)
	# diplomacy: standing with each faction and the world's wars (ui/relations.tscn)
	bar.add_child(UiKit.button("Relations", func(): Game.goto(Relations.SCENE, {"back": Game.screen_params.get("back", "")}), "Row", 150))
	# everything the company carries: gear, stash, food and drink, goods and coin (ui/baggage.gd)
	bar.add_child(UiKit.button("Baggage", func(): Game.goto(BAGGAGE, {"back": Game.screen_params.get("back", "")}), "Row", 140))
	bar.add_child(UiKit.button("Back", _back, "", 140))
	provisions = UiKit.vbox(4)
	f["root"].add_child(provisions)
	var body := UiKit.hbox(12)
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	f["root"].add_child(body)
	# left: roster
	var lp := UiKit.panel()
	lp.custom_minimum_size.x = 370
	body.add_child(lp)
	var lv := UiKit.vbox(6)
	lp.add_child(lv)
	var sc := UiKit.scroll()
	lv.add_child(sc)
	list_box = UiKit.vbox(4)
	list_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(list_box)
	# right: sheet
	var right := UiKit.vbox(0)
	UiKit.expand(right, true, true)
	body.add_child(right)
	tabs_box = UiKit.hbox(6)
	right.add_child(tabs_box)
	var rp := UiKit.panel()
	UiKit.expand(rp, true, true)
	right.add_child(rp)
	var rv := UiKit.vbox(8)
	rp.add_child(rv)
	page = UiKit.vbox(8)
	UiKit.expand(page, true, true)
	rv.add_child(page)
	actions = UiKit.hbox(8)
	rv.add_child(actions)
	var cap := Game.lead_officer()
	if Game.screen_params.has("unit"):
		selected_uid = int(Game.screen_params["unit"])
	elif cap != null:
		selected_uid = cap.uid
	elif not Game.company.is_empty():
		selected_uid = Game.company[0].uid
	refresh()

func _back() -> void:
	var dest: String = Game.screen_params.get("back", "town" if Game.location != "" else "map")
	Game.goto(dest)

func select(uid: int) -> void:
	selected_uid = uid
	var u := Game.unit_by_uid(uid)
	if tab == "Squad" and (u == null or not u.is_officer()):
		tab = "Overview"
	refresh()

## A tab switch rebuilds the sheet only (v0.014: the roster list beside it took a health report per man, ~70 ms).
func show_tab(t: String) -> void:
	tab = t
	_build_sheet()

func refresh() -> void:
	purse.text = UiKit.purse_text(Game)
	_build_provisions()
	_build_list()
	_build_sheet()

# ------------------------------------------------------------------ food and drink (core/food.gd)
## Ration toggles (company-wide), days of food and drink at these rations, and one warning banner.
func _build_provisions() -> void:
	UiKit.clear(provisions)
	var p := UiKit.panel("Inset")
	provisions.add_child(p)
	var h := UiKit.flow(8)
	p.add_child(h)
	var fl := UiKit.label("Food: %s" % Food.days_text(Food.food_days(Game)), "H2")
	fl.custom_minimum_size.x = 170
	h.add_child(fl)
	for r in Food.FOOD_RATIONS:
		h.add_child(UiKit.button(Food.RATION_LABELS[r], set_ration.bind("food", r), "RowOn" if Game.rations.get("food") == r else "Row", 96))
	h.add_child(UiKit.spacer())
	var dl := UiKit.label("Drink: %s" % ("none served" if Game.rations.get("drink") == "dry" else Food.days_text(Food.drink_days(Game))), "H2")
	dl.custom_minimum_size.x = 190
	h.add_child(dl)
	for r in Food.DRINK_RATIONS:
		h.add_child(UiKit.button(Food.RATION_LABELS[r], set_ration.bind("drink", r), "RowOn" if Game.rations.get("drink") == r else "Row", 96))
	var stock := UiKit.label("Stock: %d meals, %d mugs of beer, %d cups of wine" % [Food.stock(Game, "meal"), Food.stock(Game, "beer"), Food.stock(Game, "wine")], "Muted")
	var warn := Food.warning(Game)
	var row := UiKit.flow(10)
	row.add_child(stock)
	if warn != "":
		var chip := UiKit.chip(warn, UiTheme.BAD)
		chip.name = "FoodWarning"
		row.add_child(chip)
	provisions.add_child(row)

func set_ration(kind: String, value: String) -> void:
	Game.rations[kind] = value
	refresh()

# ------------------------------------------------------------------ roster list
func _build_list() -> void:
	UiKit.clear(list_box)
	var leaders := Roster.leaders(Game)
	for l in leaders:
		var troops := Roster.troops_of(Game, l.uid)
		list_box.add_child(_row(l, "%s, %s   %d/%d" % [l.name, l.title, troops.size(), Roster.MAX_TROOPS], true))
		for t in troops:
			list_box.add_child(_row(t, "%s, %s" % [t.name, t.title], false))
	var un := Roster.unassigned(Game)
	if not un.is_empty():
		list_box.add_child(UiKit.label("Unassigned", "H2"))
		for t in un:
			list_box.add_child(_row(t, "%s, %s" % [t.name, t.title], false))
	var foot := UiKit.label("%d in the company, %d officers. Stash: %d items." % [Game.company.size(), Roster.officer_count(Game), Game.stash.size()], "Muted", true)
	list_box.add_child(foot)
	if Game.has_method("best_skill"):
		var best := []
		for s in DB.UTILITY_SKILLS_V1:
			var lv: int = Game.best_skill(s)
			if lv > 0:
				best.append("%s %s" % [UiWords.skill_level(lv), UiWords.skill_name(s).to_lower()])
		var txt := "Company's best: " + (", ".join(PackedStringArray(best)) if not best.is_empty() else "no utility skills")
		if Game.has_method("loot_fraction"):
			txt += ". Loot share %d%%." % int(round(Game.loot_fraction() * 100))
		list_box.add_child(UiKit.label(txt, "Muted", true))

func _row(u: Unit, text: String, leader: bool) -> Button:
	var b := UiKit.button("", select.bind(u.uid), "RowOn" if u.uid == selected_uid else "Row")
	b.custom_minimum_size = Vector2(0, 60 if leader else 52)
	var m := MarginContainer.new()
	m.set_anchors_preset(Control.PRESET_FULL_RECT)
	m.add_theme_constant_override("margin_left", 8 if leader else 34)
	m.add_theme_constant_override("margin_right", 8)
	m.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var h := UiKit.hbox(8)
	h.mouse_filter = Control.MOUSE_FILTER_IGNORE
	m.add_child(h)
	var p := UiKit.portrait(u, 46 if leader else 38)
	p.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	h.add_child(p)
	# the name has its own line; status tags sit under it and shrink (ellipsis) to share the width, so a
	# "badly wounded" + "stays in camp" pair can never push the name off the row
	var col := UiKit.vbox(2)
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	h.add_child(col)
	var l := UiKit.label(text, "H2" if leader else "")
	l.name = "RosterName"
	if leader:
		l.add_theme_font_size_override("font_size", 20)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	l.custom_minimum_size.x = 60
	l.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_child(l)
	var tags := []
	var rep := HealthReport.describe(u)   # one health report per card (v0.014 speed)
	var st: String = rep.get("status", "healthy")
	if st != "healthy":
		tags.append([st, UiTheme.WARN if st == "wounded" else UiTheme.BAD])
	var why: String = Game.deploy_block_reason(u, rep)
	if why != "" and why != "dead":
		tags.append(["stays in camp" + ("" if why == st else ": " + why), UiTheme.BAD])
	if not tags.is_empty():
		b.custom_minimum_size.y = 78 if leader else 72
		var tr := UiKit.hbox(4)
		tr.name = "RosterTags"
		tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
		col.add_child(tr)
		for tg in tags:
			tr.add_child(_tag(String(tg[0]), tg[1]))
	b.add_child(m)
	return b

## A small status tag that gives up width (ellipsis) instead of pushing the row wider.
func _tag(text: String, bg: Color) -> Control:
	var c := UiKit.chip(text, bg)
	var cl := c.get_child(0) as Label
	cl.add_theme_font_size_override("font_size", 15)
	cl.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	cl.custom_minimum_size.x = 24
	c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	c.size_flags_stretch_ratio = maxf(1.0, text.length() / 8.0)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	c.tooltip_text = text
	return c

# ------------------------------------------------------------------ sheet
func _build_sheet() -> void:
	UiKit.clear(tabs_box)
	UiKit.clear(page)
	UiKit.clear(actions)
	var u := Game.unit_by_uid(selected_uid)
	if u == null:
		page.add_child(UiKit.label("Nobody selected.", "Muted"))
		return
	var names := ["Overview", "Mind", "Skills", "Gear", "Health"]
	if u.is_officer():
		names.append("Squad")
	tabs_box.add_child(UiKit.tab_strip(names, tab, show_tab))
	match tab:
		"Mind": page.add_child(UnitSheet.mind(u))
		"Skills": page.add_child(UnitSheet.skills(u))
		"Gear": page.add_child(UnitSheet.gear(u, Game, self, refresh))
		"Health": page.add_child(UnitSheet.health(u))
		"Squad": page.add_child(_squad_page(u))
		_: page.add_child(UnitSheet.overview(u))
	_build_actions(u)

func _build_actions(u: Unit) -> void:
	if not u.is_officer():
		actions.add_child(UiKit.button("Move to squad", func(): _pick_squad(u), "", 0))
		var pr := UiKit.button("Promote to officer", func():
			var err := Roster.promote(Game, u)
			if err != "":
				UiKit.toast(self, err, false)
			else:
				UiKit.toast(self, "%s now leads a squad" % u.name)
			refresh(), "", 0)
		pr.disabled = Roster.officer_count(Game) >= Roster.MAX_OFFICERS
		actions.add_child(pr)
	actions.add_child(UiKit.spacer())
	if u.role != "captain":
		actions.add_child(UiKit.button("Dismiss", func():
			UiKit.confirm(self, "Dismiss %s? Their gear goes to the stash.%s" % [u.name, " Their troops become unassigned." if u.is_officer() else ""], "Dismiss", func():
				Roster.dismiss(Game, u)
				selected_uid = Game.lead_officer().uid if Game.lead_officer() else -1
				tab = "Overview"
				refresh()), "Danger", 140))

func _pick_squad(u: Unit) -> void:
	var opts := []
	for l in Roster.leaders(Game):
		var n := Roster.troops_of(Game, l.uid).size()
		opts.append({"text": "%s's squad" % l.name, "value": l.uid, "detail": "%d/%d" % [n, Roster.MAX_TROOPS],
			"disabled": l.uid == u.squad or n >= Roster.MAX_TROOPS})
	opts.append({"text": "Unassigned", "value": -1, "disabled": u.squad == -1})
	UiKit.picker(self, "Move %s to..." % u.name, opts, func(uid):
		var err := Roster.move_troop(Game, u, uid)
		if err != "":
			UiKit.toast(self, err, false)
		refresh())

# ------------------------------------------------------------------ squad uniform
func _squad_page(off: Unit) -> Control:
	Roster.ensure_squad(Game, off.uid)
	var rule: Dictionary = Game.squads[off.uid]
	if not rule.has("uniform"):
		rule["uniform"] = {}
	var sc := UiKit.scroll()
	var v := UiKit.vbox(8)
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(v)
	var top := UiKit.flow(10)
	top.add_child(UiKit.label("%s's squad uniform" % off.name, "H2"))
	top.add_child(UiKit.spacer())
	top.add_child(UiKit.label("Metal:", "Muted"))
	for m in ["any", "copper", "tin"]:
		var cur: String = rule.get("material", "any")
		top.add_child(UiKit.button(m, func():
			rule["material"] = m
			refresh(), "RowOn" if cur == m else "Row", 96))
	v.add_child(top)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 6)
	v.add_child(grid)
	var uni: Dictionary = rule["uniform"]
	var two := Outfit.is_two_handed(String(uni.get("main_hand", "")))
	for slot in DB.EQUIP_SLOTS:
		var row := UiKit.hbox(8)
		row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var sl := UiKit.label(UiWords.slot_name(slot), "Muted")
		sl.custom_minimum_size.x = 118
		row.add_child(sl)
		var txt := Outfit.template_name(uni[slot]) if uni.has(slot) and uni[slot] != "" else "(free choice)"
		if slot == "off_hand" and two:
			txt = "(none: two-handed)"
		var b := UiKit.button(txt, func(): _pick_uniform(off, slot), "Row")
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		b.disabled = slot == "off_hand" and two
		row.add_child(b)
		grid.add_child(row)
	var acts := UiKit.flow(8)
	acts.add_child(UiKit.button("Apply uniform", func():
		var r := Outfit.apply_uniform(Game.squads, Game.company, off.uid, Game.stash)
		refresh()
		UnitSheet._report(self, r["missing"], r["equipped"]), "", 0))
	acts.add_child(UiKit.button("Apply all squads", func():
		var miss := []
		var n := 0
		for l in Roster.leaders(Game):
			var r := Outfit.apply_uniform(Game.squads, Game.company, l.uid, Game.stash)
			miss.append_array(r["missing"])
			n += int(r["equipped"])
		refresh()
		UnitSheet._report(self, miss, n), "Row", 0))
	v.add_child(acts)
	v.add_child(UiKit.label("Troops", "H2"))
	var troops := Roster.troops_of(Game, off.uid)
	if troops.is_empty():
		v.add_child(UiKit.label("No troops yet. Hire in town or move troops here.", "Muted"))
	for t in troops:
		var miss := []
		var want := Outfit.wanted(Game.squads, t)
		for slot in want:
			if want[slot] != "" and (not t.equip.has(slot) or t.equip[slot].tid != want[slot]):
				miss.append(Outfit.template_name(want[slot]))
		var line := "%s: %s" % [t.name, "fully outfitted" if miss.is_empty() else "lacks " + ", ".join(miss)]
		var l := UiKit.label(line, "Good" if miss.is_empty() else "Bad", true)
		v.add_child(l)
	return sc

func _pick_uniform(off: Unit, slot: String) -> void:
	var opts := [{"text": "(free choice: keep whatever they have)", "value": "__free"}]
	for tid in Outfit.templates_for_slot(slot):
		opts.append({"text": Outfit.template_name(tid) + (" (two-handed)" if Outfit.is_two_handed(tid) else ""),
			"value": tid, "detail": UiWords.faction_name(UnitSheet._culture_faction(tid))})
	UiKit.picker(self, "Uniform %s for %s's squad" % [UiWords.slot_name(slot).to_lower(), off.name], opts, func(val):
		var uni: Dictionary = Game.squads[off.uid]["uniform"]
		if val == "__free":
			uni.erase(slot)
		else:
			uni[slot] = val
			if slot == "main_hand" and Outfit.is_two_handed(val):
				uni.erase("off_hand")
		refresh())
