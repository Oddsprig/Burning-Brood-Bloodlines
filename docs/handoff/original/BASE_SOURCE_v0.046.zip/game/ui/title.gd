extends Control
## Title screen: New Campaign, Continue (if a save exists), Quit (PC only).

func _ready() -> void:
	theme = UiTheme.get_theme()
	set_anchors_preset(PRESET_FULL_RECT)
	var bg := TitleBackdrop.new()
	bg.set_anchors_preset(PRESET_FULL_RECT)
	add_child(bg)
	var center := CenterContainer.new()
	center.set_anchors_preset(PRESET_FULL_RECT)
	add_child(center)
	var v := UiKit.vbox(14)
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	center.add_child(v)
	var t := UiKit.label("Copper Oath", "Title")
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(t)
	var sub := UiKit.label("a mercenary company sworn for coin", "Header")
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.add_theme_font_size_override("font_size", 24)
	v.add_child(sub)
	var gap := Control.new()
	gap.custom_minimum_size.y = 24
	v.add_child(gap)
	var bv := UiKit.vbox(12)
	var holder := CenterContainer.new()
	holder.add_child(bv)
	v.add_child(holder)
	var cont := UiKit.button("Continue", _continue, "", 360)
	cont.custom_minimum_size.y = 64
	cont.disabled = not Game.has_save()
	if Game.has_save():
		bv.add_child(cont)
	var ng := UiKit.button("New Campaign", _new, "", 360)
	ng.custom_minimum_size.y = 64
	bv.add_child(ng)
	if not Game.has_save():
		bv.add_child(cont)
	var st := UiKit.button("Settings", func(): Game.goto("settings", {"back": "title"}), "Row", 360)
	st.custom_minimum_size.y = 56
	bv.add_child(st)
	if not (OS.has_feature("mobile") or OS.has_feature("web")):
		var q := UiKit.button("Quit", func(): get_tree().quit(), "Row", 360)
		q.custom_minimum_size.y = 56
		bv.add_child(q)

func _new() -> void:
	Game.goto("newgame", {"back": "title"})   # world size and the years before (ui/newgame.gd), then presim and the map

func _continue() -> void:
	if Game.load_game():
		Game.goto("town" if Game.location != "" else "map")


class TitleBackdrop extends Control:
	## Dusk sky, layered hills, a copper sun and a company banner, drawn in code.
	func _ready() -> void:
		mouse_filter = MOUSE_FILTER_IGNORE
		resized.connect(queue_redraw)

	func _draw() -> void:
		var w := size.x
		var h := size.y
		var bands := 24
		for i in bands:
			var t := float(i) / bands
			var c := Color("1d2547").lerp(Color("c8643a"), pow(t, 1.6)).lerp(Color("f2b25a"), maxf(0.0, t - 0.8) * 3.0)
			draw_rect(Rect2(0, h * t * 0.75, w, h * 0.75 / bands + 1), c)
		draw_circle(Vector2(w * 0.72, h * 0.55), h * 0.16, Color("f4a24a"))
		draw_circle(Vector2(w * 0.72, h * 0.55), h * 0.13, Color("ffc76a"))
		_hills(h * 0.58, 70.0, 0.006, Color("5a3550"), 1)
		_hills(h * 0.68, 50.0, 0.011, Color("3a2438"), 2)
		_hills(h * 0.8, 36.0, 0.017, Color("21141f"), 3)
		# banner pole and a copper-and-blue pennant
		var px := w * 0.16
		var top := h * 0.3
		draw_line(Vector2(px, h * 0.86), Vector2(px, top), Color("2a1a10"), 8)
		var pts := PackedVector2Array([Vector2(px, top + 6), Vector2(px + 150, top + 34), Vector2(px + 110, top + 62),
			Vector2(px + 150, top + 92), Vector2(px, top + 116)])
		draw_colored_polygon(pts, Color("c0622a"))
		draw_polyline(pts, Color("3a1a08"), 3)
		draw_circle(Vector2(px + 52, top + 61), 20, Color("f0c24f"))
		draw_circle(Vector2(px + 52, top + 61), 11, Color("c0622a"))
		draw_rect(Rect2(0, h * 0.86, w, h * 0.14), Color("140c12"))

	func _hills(base: float, amp: float, freq: float, col: Color, s: int) -> void:
		var pts := PackedVector2Array()
		pts.append(Vector2(0, size.y))
		var x := 0.0
		while x <= size.x + 20:
			pts.append(Vector2(x, base - amp * (0.6 * sin(x * freq + s) + 0.4 * sin(x * freq * 2.7 + s * 2.0))))
			x += 20.0
		pts.append(Vector2(size.x, size.y))
		draw_colored_polygon(pts, col)
