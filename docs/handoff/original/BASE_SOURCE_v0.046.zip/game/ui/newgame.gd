extends Control
## New Campaign world size and history span: one day through 100 years, using
## the existing integer-day simulation. The slider gives short histories room:
## individual days to 30, then 60/90 days, then whole years. Begin opens the
## visible generation/history screen; Back returns to the title.

const SLIDER_MAX := 131
const PRESETS := [[1, "1 day"], [7, "1 week"], [30, "1 month"],
	[120, "1 year"], [600, "5 years"], [2400, "20 years"], [12000, "100 years"]]

var size_key := WorldGen.WORLD_SIZE
var history_days := CampaignWorld.PRESIM_YEARS * CampaignWorld.PRESIM_YEAR_DAYS
var size_row: HBoxContainer
var size_info: Label
var slider: HSlider
var span_lbl: Label
var est: Label

func _ready() -> void:
	theme = UiTheme.get_theme()
	set_anchors_preset(PRESET_FULL_RECT)
	size_key = WorldGen.gen_size if WorldGen.SIZES.has(WorldGen.gen_size) else WorldGen.WORLD_SIZE
	history_days = CampaignWorld.presim_span_days
	var bg := WoodBg.new()
	bg.set_anchors_preset(PRESET_FULL_RECT)
	add_child(bg)
	var sc := UiKit.scroll()
	sc.set_anchors_preset(PRESET_FULL_RECT)
	add_child(sc)
	var center := CenterContainer.new()
	UiKit.expand(center, true, true)
	sc.add_child(center)
	var p := UiKit.panel()
	p.custom_minimum_size = Vector2(640, 0)
	center.add_child(p)
	var v := UiKit.vbox(12)
	p.add_child(v)
	var top := UiKit.hbox()
	var t := UiKit.label("New Campaign", "H2")
	t.add_theme_font_size_override("font_size", 32)
	top.add_child(t)
	top.add_child(UiKit.spacer())
	top.add_child(UiKit.button("Back", _back, "Row", 140))
	v.add_child(top)
	v.add_child(HSeparator.new())
	# ------------------------------------------------------------------ world size
	v.add_child(UiKit.label("World size", "H2"))
	size_row = UiKit.hbox(10)
	v.add_child(size_row)
	size_info = UiKit.label("", "Muted", true)
	v.add_child(size_info)
	# ------------------------------------------------------------------ history before arrival
	v.add_child(UiKit.label("History before you arrive", "H2"))
	v.add_child(UiKit.label("Families, trades, loans, wars, births and deaths unfold before you arrive.", "Muted", true))
	var yr := UiKit.hbox(10)
	v.add_child(yr)
	yr.add_child(UiKit.button("-", func(): _step_span(-1), "Row", 56))
	slider = HSlider.new()
	slider.min_value = 0
	slider.max_value = SLIDER_MAX
	slider.step = 1
	slider.value = span_index(history_days)
	slider.tooltip_text = "1–30 days · 60 and 90 days · 1–100 years"
	slider.custom_minimum_size = Vector2(200, UiKit.TAP)
	slider.focus_mode = Control.FOCUS_NONE
	UiKit.expand(slider)
	slider.value_changed.connect(func(x: float): _set_days(span_days(int(x))))
	yr.add_child(slider)
	yr.add_child(UiKit.button("+", func(): _step_span(1), "Row", 56))
	span_lbl = UiKit.label("", "H2")
	span_lbl.custom_minimum_size.x = 145
	span_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	span_lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	yr.add_child(span_lbl)
	var steps := HFlowContainer.new()
	steps.add_theme_constant_override("h_separation", 8)
	steps.add_theme_constant_override("v_separation", 8)
	v.add_child(steps)
	for preset in PRESETS:
		var n := int(preset[0])
		var b := UiKit.button(String(preset[1]), _set_days.bind(n), "Row", 0)
		b.tooltip_text = "%d simulation day%s; a year has %d days" % [n, "" if n == 1 else "s", CampaignWorld.PRESIM_YEAR_DAYS]
		steps.add_child(b)
	# ------------------------------------------------------------------ the estimate and Begin
	v.add_child(HSeparator.new())
	est = UiKit.label("", "", true)
	v.add_child(est)
	var go := UiKit.button("Begin", _begin, "", 0)
	go.custom_minimum_size.y = 64
	v.add_child(go)
	_refresh()

static func span_days(index: int) -> int:
	index = clampi(index, 0, SLIDER_MAX)
	if index < 30:
		return index + 1
	if index <= 32:
		return (index - 28) * Calendar.DAYS_PER_SEASON
	return (index - 31) * CampaignWorld.PRESIM_YEAR_DAYS

static func span_index(days: int) -> int:
	days = clampi(days, CampaignWorld.PRESIM_DAYS_MIN, CampaignWorld.PRESIM_DAYS_MAX)
	if days <= 30:
		return days - 1
	if days < CampaignWorld.PRESIM_YEAR_DAYS:
		return clampi(roundi(float(days) / Calendar.DAYS_PER_SEASON) + 28, 29, 32)
	return clampi(roundi(float(days) / CampaignWorld.PRESIM_YEAR_DAYS) + 31, 32, SLIDER_MAX)

func _step_span(direction: int) -> void:
	_set_days(span_days(span_index(history_days) + direction))

func _set_days(n: int) -> void:
	history_days = clampi(n, CampaignWorld.PRESIM_DAYS_MIN, CampaignWorld.PRESIM_DAYS_MAX)
	if slider != null:
		slider.set_value_no_signal(span_index(history_days))
	_refresh()

func _set_years(n: int) -> void:
	_set_days(CampaignWorld.presim_days(n))

func _pick_size(k: String) -> void:
	size_key = k
	_refresh()

func _refresh() -> void:
	UiKit.clear(size_row)
	for k in WorldGen.SIZE_ORDER:
		var row: Dictionary = WorldGen.SIZES[k]
		var b := UiKit.button(String(row["label"]), _pick_size.bind(k), "RowOn" if k == size_key else "Row", 0)
		UiKit.expand(b)
		size_row.add_child(b)
	size_info.text = "%s: %s.%s" % [String(WorldGen.SIZES[size_key]["label"]), String(WorldGen.SIZES[size_key].get("towns", "")),
		"  (the default)" if size_key == WorldGen.WORLD_SIZE else ""]
	span_lbl.text = CampaignWorld.presim_span_text(history_days)
	est.text = "Startup will build a %s world and simulate %s. Larger worlds and longer histories take longer." % [
		String(WorldGen.SIZES[size_key]["label"]).to_lower(), CampaignWorld.presim_span_text(history_days)]

func _begin() -> void:
	WorldGen.gen_size = size_key
	CampaignWorld.presim_span_days = history_days
	Game.goto("presim", {"new_world": true})   # visible generation, the years before, then the map

func _back() -> void:
	Game.goto(String(Game.screen_params.get("back", "title")))
